/*
  Módulo 4 — Funções
  Exercício 06 — Desconto em cascata
  Nível: Intermediário

  Objetivo: Uma função chamando outra (composição).

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO 1: Crie aplicarDesconto(preco, porcentagem) que devolve o preço com desconto.
// TODO 2: Crie aplicarCupom(preco) que tira R$ 5,00 fixos, mas nunca devolve
//         menos que zero (dica: Math.max(0, ...)).
// TODO 3: Partindo de 50, aplique 10% de desconto e mostre em #passo1;
//         depois aplique o cupom e mostre em #passo2.
// TODO 4: Crie precoFinal(preco) que chama as duas funções acima e mostre
//         o resultado em #final. Os valores devem bater com os passos.

function aplicarDesconto(preco, porcentagem) {
  return preco * (1 - porcentagem / 100);
}
function aplicarCupom(preco) {
  return Math.max(0, preco - 5);
}
function precoFinal(preco) {
  return aplicarCupom(aplicarDesconto(preco, 10));
}
const passo1 = aplicarDesconto(50, 10);
const passo2 = aplicarCupom(passo1);
document.querySelector("#passo1").textContent = `Após 10% de desconto: R$ ${passo1.toFixed(2)}`;
document.querySelector("#passo2").textContent = `Após o cupom: R$ ${passo2.toFixed(2)}`;
document.querySelector("#final").textContent = `Preço final: R$ ${precoFinal(50).toFixed(2)}`;
