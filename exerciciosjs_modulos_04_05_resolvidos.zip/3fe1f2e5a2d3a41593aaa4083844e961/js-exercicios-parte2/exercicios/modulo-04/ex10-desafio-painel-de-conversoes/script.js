/*
  Módulo 4 — Funções
  Exercício 10 — Desafio: painel de conversões
  Nível: Desafio

  Objetivo: Mini-projeto do módulo: funções de cálculo + uma de exibição.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO 1: Crie três funções de CÁLCULO (com return):
//         celsiusParaF(c), kmParaMilhas(km) (1 km = 0.621371 mi),
//         reaisParaDolar(r) (use a constante COTACAO abaixo).
// TODO 2: Crie UMA função de EXIBIÇÃO mostrar(texto) que escreve em #resultado.
// TODO 3: Faça cada botão chamar a conversão certa com o valor 100 e mostrar
//         algo como "100 °C = 212.00 °F". Dica: use botao.dataset.tipo e um switch.
// DESAFIO: troque o valor fixo 100 por um <input type="number">.

const COTACAO = 5.4; // R$ por US$ (valor fictício)
const VALOR = 100;
function celsiusParaF(c) {
  return c * 9 / 5 + 32;
}
function kmParaMilhas(km) {
  return km * 0.621371;
}
function reaisParaDolar(r) {
  return r / COTACAO;
}
function mostrar(texto) {
  document.querySelector("#resultado").textContent = texto;
}
for (const botao of document.querySelectorAll("button[data-tipo]")) {
  botao.addEventListener("click", function () {
    switch (botao.dataset.tipo) {
      case "temp":
        mostrar(`${VALOR} °C = ${celsiusParaF(VALOR).toFixed(2)} °F`);
        break;
      case "dist":
        mostrar(`${VALOR} km = ${kmParaMilhas(VALOR).toFixed(2)} milhas`);
        break;
      case "moeda":
        mostrar(`R$ ${VALOR.toFixed(2)} = US$ ${reaisParaDolar(VALOR).toFixed(2)}`);
        break;
    }
  });
}
