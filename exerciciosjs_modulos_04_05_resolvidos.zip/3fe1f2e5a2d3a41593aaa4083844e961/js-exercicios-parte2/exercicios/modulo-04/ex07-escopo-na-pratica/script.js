/*
  Módulo 4 — Funções
  Exercício 07 — Escopo na prática
  Nível: Intermediário

  Objetivo: Entender variável global x local consertando um contador.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// Este código tem um problema de ESCOPO: o contador nunca passa de 1.
// TODO 1: Rode, clique várias vezes e observe.
// TODO 2: Escreva aqui embaixo, num comentário, POR QUE isso acontece.
// TODO 3: Corrija movendo UMA linha de lugar.
// TODO 4: Crie também um botão "Alguém saiu" (no HTML) que diminui o contador,
//         sem deixar ficar negativo.

// Antes, pessoas era criada com 0 dentro da função a cada clique.
// Agora fica fora das funções e mantém seu valor entre os cliques.
let pessoas = 0;
function atualizarTotal() {
  document.querySelector("#total").textContent = pessoas;
}
function registrarEntrada() {
  pessoas = pessoas + 1;
  atualizarTotal();
}
function registrarSaida() {
  pessoas = Math.max(0, pessoas - 1);
  atualizarTotal();
}
document.querySelector("#entrar").addEventListener("click", registrarEntrada);
// Cria o botão pelo JavaScript para manter o index.html original intacto.
const botaoSair = document.createElement("button");
botaoSair.id = "sair";
botaoSair.textContent = "Alguém saiu";
document.querySelector("#entrar").insertAdjacentElement("afterend", botaoSair);
botaoSair.addEventListener("click", registrarSaida);
