/*
  Módulo 5 — Arrays e objetos
  Exercício 10 — Desafio: playlist da turma
  Nível: Desafio

  Objetivo: Mini-projeto: filtrar, ordenar e somar dados reais.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const musicas = [
  { titulo: "Música A", genero: "pop", segundos: 210, votos: 18 },
  { titulo: "Música B", genero: "rock", segundos: 260, votos: 25 },
  { titulo: "Música C", genero: "funk", segundos: 185, votos: 31 },
  { titulo: "Música D", genero: "pop", segundos: 198, votos: 9 },
  { titulo: "Música E", genero: "rock", segundos: 305, votos: 14 },
  { titulo: "Música F", genero: "funk", segundos: 172, votos: 22 }
];

// TODO 1: Crie formatarTempo(segundos) -> "3:30" (dica: Math.floor e %,
//         e padStart(2, "0") para os segundos).
// TODO 2: Crie renderizar() que:
//         - filtra pelo gênero escolhido no select ("todos" mostra tudo);
//         - se o checkbox estiver marcado, ordena por votos (maior primeiro);
//         - mostra cada música como <li>: "Título — 3:30 — 18 votos";
//         - mostra em #duracao a duração total da lista exibida.
// TODO 3: Chame renderizar() no início e nos eventos "change" do select
//         e do checkbox.

function formatarTempo(segundos) {
  const minutos = Math.floor(segundos / 60);
  const restoSegundos = segundos % 60;
  return `${minutos}:${String(restoSegundos).padStart(2, "0")}`;
}

function renderizar() {
  const generoSelecionado = document.querySelector("#genero").value;
  const ordenarPorVotos = document.querySelector("#ordenar").checked;

  let listaExibida = musicas.filter(musica =>
    generoSelecionado === "todos" || musica.genero === generoSelecionado
  );

  if (ordenarPorVotos) {
    listaExibida = [...listaExibida].sort((a, b) => b.votos - a.votos);
  }

  document.querySelector("#lista").innerHTML = listaExibida.map(musica =>
    `<li>${musica.titulo} — ${formatarTempo(musica.segundos)} — ${musica.votos} votos</li>`
  ).join("");

  const duracaoTotal = listaExibida.reduce((total, musica) => total + musica.segundos, 0);
  document.querySelector("#duracao").textContent = `Duração total: ${formatarTempo(duracaoTotal)}`;
}

document.querySelector("#genero").addEventListener("change", renderizar);
document.querySelector("#ordenar").addEventListener("change", renderizar);
renderizar();
