/*
  Módulo 5 — Arrays e objetos
  Exercício 04 — map: transformando listas
  Nível: Básico

  Objetivo: Criar arrays novos com map.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const numeros = [3, 8, 15, 22];
const nomes = ["ana", "léo", "bia"];

document.querySelector("#original").textContent = numeros.join(", ");

// TODO 1: Use map para criar "dobros" e mostre em #dobro.
// TODO 2: Use map para criar "emReais" com strings tipo "R$ 3.00"
//         (toFixed(2)) e mostre em #reais.
// TODO 3: Use map para colocar os nomes em MAIÚSCULAS e mostre em #maiusculas.
// TODO 4: Confira no console que o array "numeros" NÃO mudou.

const dobros = numeros.map(numero => numero * 2);
document.querySelector("#dobro").textContent = dobros.join(", ");

const emReais = numeros.map(numero => `R$ ${numero.toFixed(2)}`);
document.querySelector("#reais").textContent = emReais.join(" | ");

const maiusculas = nomes.map(nome => nome.toUpperCase());
document.querySelector("#maiusculas").textContent = maiusculas.join(", ");

console.log("Array original (não foi alterado):", numeros);
