/*
  Módulo 5 — Arrays e objetos
  Exercício 09 — Ache o bug: arrays e objetos
  Nível: Desafio

  Objetivo: Corrigir erros clássicos de índice, filter e notação de colchetes.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO: Há 4 bugs. Corrija e comente cada um.
const alunos = [
  { nome: "Ana", nota: 7 },
  { nome: "Bruno", nota: 9.5 },
  { nome: "Carla", nota: 8 }
];

// 1) O último índice é length - 1, pois os índices começam em zero.
const ultimo = alunos[alunos.length - 1].nome;

// 2) find devolve um único objeto; filter devolveria um array.
const destaque = alunos.find(a => a.nota === 9.5);

// 3) O nome correto da propriedade é length.
const quantidade = alunos.length;

// 4) Para usar o conteúdo de uma variável como chave, usamos colchetes.
const campo = "nota";
const notaDoBruno = alunos[1][campo];

document.querySelector("#saida").textContent =
  `${ultimo} | ${destaque.nome} | ${quantidade} | ${notaDoBruno}`;
