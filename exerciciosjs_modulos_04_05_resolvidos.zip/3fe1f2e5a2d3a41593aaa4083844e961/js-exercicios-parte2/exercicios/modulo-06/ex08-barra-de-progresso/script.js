/*
  Módulo 6 — O DOM
  Exercício 08 — Barra de progresso
  Nível: Intermediário

  Objetivo: Usar style quando o valor é calculado na hora.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

let feitos = 0;
const TOTAL = 11;

// TODO 1: Crie atualizar() que:
//         - mostra "feitos" em #feitos;
//         - calcula a porcentagem e coloca em barra.style.width (ex.: "45%");
//         - adiciona a classe "completa" quando chegar a 100%
//           (dica: classList.toggle("completa", condição)).
// TODO 2: #concluir soma 1 (sem passar de TOTAL) e chama atualizar().
// TODO 3: #zerar volta para 0.
