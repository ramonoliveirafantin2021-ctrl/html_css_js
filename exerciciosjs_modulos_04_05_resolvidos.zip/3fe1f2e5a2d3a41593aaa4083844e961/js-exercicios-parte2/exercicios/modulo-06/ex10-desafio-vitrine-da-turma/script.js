/*
  Módulo 6 — O DOM
  Exercício 10 — Desafio: vitrine da turma
  Nível: Desafio

  Objetivo: Mini-projeto: dados → elementos → contagem por categoria.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const projetos = [
  { titulo: "To-do list", autor: "Ana", tecnologia: "JavaScript", destaque: true },
  { titulo: "Portfólio", autor: "Bruno", tecnologia: "HTML/CSS", destaque: false },
  { titulo: "Quiz de História", autor: "Carla", tecnologia: "JavaScript", destaque: false },
  { titulo: "Landing page", autor: "Davi", tecnologia: "HTML/CSS", destaque: true },
  { titulo: "Calculadora", autor: "Elisa", tecnologia: "JavaScript", destaque: false },
  { titulo: "Blog", autor: "Fábio", tecnologia: "PHP", destaque: false }
];

// TODO 1: criarCartao(projeto) devolve um ELEMENTO <article class="projeto">
//         (createElement) com <h3> título, <p> autor e <span class="tag"> tecnologia.
//         Projetos em destaque recebem também a classe "destaque".
// TODO 2: Renderize todos os cartões em #vitrine.
// TODO 3: Em #resumo, mostre quantos projetos existem por tecnologia,
//         ex.: "JavaScript: 3 · HTML/CSS: 2 · PHP: 1".
//         Dica: monte um objeto contador { JavaScript: 3, ... } com forEach.
