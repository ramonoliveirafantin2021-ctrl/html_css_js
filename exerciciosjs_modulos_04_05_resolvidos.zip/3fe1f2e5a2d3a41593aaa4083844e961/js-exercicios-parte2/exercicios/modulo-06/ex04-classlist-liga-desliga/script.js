/*
  Módulo 6 — O DOM
  Exercício 04 — classList: liga-desliga
  Nível: Básico

  Objetivo: Usar add, remove, toggle e contains.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO 1: #b1 alterna a classe "acesa" na lâmpada 1 (toggle).
// TODO 2: #todas acende as três (querySelectorAll + forEach + add).
// TODO 3: #nenhuma apaga as três (remove).
// TODO 4: Crie atualizarStatus() que conta quantas têm a classe "acesa"
//         (use contains) e mostra "X lâmpada(s) acesa(s)" em #status.
//         Chame depois de cada botão.
