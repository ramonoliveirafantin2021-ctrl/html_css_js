/*
  Módulo 6 — O DOM
  Exercício 09 — Ache o bug: DOM
  Nível: Desafio

  Objetivo: Diagnosticar erros de seleção e inserção lendo o console.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO: Este script tem 4 bugs. Leia as mensagens do console,
//       corrija e comente cada correção. Resultado esperado:
//       - título "Título novo";
//       - um <li>"Item criado"</li> dentro de .itens;
//       - as notas 4 e 5 em vermelho.

const titulo = document.querySelector("titulo");
titulo.textContent = "Título novo";

const li = document.createElement("li");
li.textContent = "Item criado";

const notas = document.querySelector(".nota");
notas.forEach(n => {
  if (n.textContent < 6) n.classList.add("vermelha");
});

document.querySelector("#itens").append(li);
