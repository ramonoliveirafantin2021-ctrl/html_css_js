/*
  Módulo 6 — O DOM
  Exercício 07 — Tabela dinâmica
  Nível: Intermediário

  Objetivo: Montar uma tabela inteira a partir de um array de objetos.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const times = [
  { turma: "2º Info A", pontos: 9, vitorias: 3 },
  { turma: "3º Info B", pontos: 12, vitorias: 4 },
  { turma: "1º Info A", pontos: 4, vitorias: 1 },
  { turma: "2º Adm", pontos: 7, vitorias: 2 }
];

// TODO 1: Ordene uma CÓPIA de "times" por pontos (maior primeiro).
// TODO 2: Para cada time, crie um <tr> com 4 <td> usando createElement.
//         A primeira coluna é a posição (1, 2, 3...).
// TODO 3: O primeiro colocado recebe a classe "lider".
// TODO 4: Coloque as linhas no <tbody> (document.querySelector("#tabela tbody")).
