/*
  Módulo 6 — O DOM
  Exercício 06 — Removendo elementos
  Nível: Intermediário

  Objetivo: remove, children e navegação na árvore.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const lista = document.querySelector("#lista");

// TODO 1: #limpar remove todos os itens com a classe "lixo".
// TODO 2: #primeiro remove o primeiro <li> (lista.firstElementChild).
// TODO 3: #ultimo remove o último <li> (lista.lastElementChild).
//         Cuidado: se a lista estiver vazia, não pode dar erro!
// TODO 4: Depois de cada ação, mostre em #contagem quantos itens restam
//         (lista.children.length).
