/*
  Módulo 6 — O DOM
  Exercício 03 — Trocando atributos
  Nível: Básico

  Objetivo: Mudar src, alt e href de elementos.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO 1: No clique de #trocar, troque o src da imagem para
//         "https://picsum.photos/id/1025/300/200" e o alt para "Outro cachorro".
// TODO 2: Troque o href do link para "https://www.w3schools.com/js/"
//         e o texto para "W3Schools".
// TODO 3: Faça o link abrir em nova aba com setAttribute("target", "_blank").
// TODO 4: Mostre no console o valor de getAttribute("href") antes e depois.
