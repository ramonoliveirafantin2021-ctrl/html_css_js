/*
  Módulo 6 — O DOM
  Exercício 01 — Selecionando elementos
  Nível: Básico

  Objetivo: Praticar querySelector com id, classe, tag e seletores compostos.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// Para cada TODO, selecione o elemento e adicione a classe "marcado"
// (elemento.classList.add("marcado")). Faça um de cada vez e confira na tela.

// TODO 1: o <h1>
// TODO 2: a PRIMEIRA .manchete
// TODO 3: a SEGUNDA .manchete (dica: querySelectorAll(...)[1] ou :nth-of-type)
// TODO 4: o <p> com classe urgente que está DENTRO de #avisos
// TODO 5: o primeiro <p> de #avisos (dica: "#avisos p")
// TODO 6: no console, mostre quantos <p> existem na página inteira.
