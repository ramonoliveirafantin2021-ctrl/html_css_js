/*
  Módulo 6 — O DOM
  Exercício 05 — Criando elementos
  Nível: Intermediário

  Objetivo: createElement, textContent, classList e append.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const turma = [
  { nome: "Ana", presente: true },
  { nome: "Bruno", presente: false },
  { nome: "Carla", presente: true },
  { nome: "Davi", presente: true },
  { nome: "Elisa", presente: false }
];
const ul = document.querySelector("#presenca");

// TODO 1: Para cada aluno, use createElement("li") (NÃO use innerHTML).
// TODO 2: O texto do <li> deve ser "Ana — presente" ou "Bruno — falta".
// TODO 3: Quem faltou recebe a classe "falta".
// TODO 4: Encaixe o <li> na lista com append.
// TODO 5: No final, crie um <p> (também com createElement) depois da lista,
//         mostrando "Presentes: 3 de 5". Use ul.after(p).
