/*
  Módulo 6 — O DOM
  Exercício 02 — textContent x innerHTML
  Nível: Básico

  Objetivo: Ver na prática a diferença e o risco de XSS.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const campo = document.querySelector("#recado");
const mural = document.querySelector("#mural");

// TODO 1: O botão #comText publica o recado no mural usando textContent.
// TODO 2: O botão #comHTML publica usando innerHTML.
// TODO 3: Clique nos dois. O que aconteceu em cada caso? Responda num comentário.
// TODO 4: Conclua num comentário: qual dos dois usar para texto que o USUÁRIO digitou?
