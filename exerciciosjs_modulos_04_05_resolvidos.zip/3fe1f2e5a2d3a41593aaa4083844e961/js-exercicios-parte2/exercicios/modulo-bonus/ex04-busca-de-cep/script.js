/*
  Módulo bônus — APIs e fetch
  Exercício 04 — Busca de CEP
  Nível: Intermediário

  Objetivo: Validar entrada, buscar e preencher campos.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// API: https://viacep.com.br/ws/SEUCEP/json/

// TODO 1: No submit (preventDefault), tire tudo que não é dígito do CEP
//         e exija 8 dígitos.
// TODO 2: Mostre "Buscando..." e faça o fetch.
// TODO 3: Se a resposta tiver dados.erro, mostre "CEP não encontrado".
// TODO 4: Senão, preencha os 4 campos e mostre "Endereço encontrado".
// TODO 5: Trate falha de rede com .catch.
