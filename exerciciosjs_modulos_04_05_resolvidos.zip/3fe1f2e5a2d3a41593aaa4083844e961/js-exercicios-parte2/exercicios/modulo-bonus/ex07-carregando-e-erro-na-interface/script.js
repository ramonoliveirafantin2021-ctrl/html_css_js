/*
  Módulo bônus — APIs e fetch
  Exercício 07 — Carregando e erro na interface
  Nível: Intermediário

  Objetivo: Mostrar estados de carregando, sucesso e erro com classes.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const URL_ES = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/ES/municipios";

// TODO 1: Crie mostrarEstado(classe, texto) que troca a classe de #painel
//         (className = classe) e o texto.
// TODO 2: No clique: estado "carregando" + desabilita o botão.
// TODO 3: Sucesso: sorteia um município da lista e mostra o nome ("ok").
// TODO 4: Erro: "Não foi possível carregar." ("erro").
// TODO 5: Em qualquer caso, reabilite o botão (.finally(() => ...)).
// DESAFIO: guarde a lista na primeira vez e não busque de novo nas próximas.
