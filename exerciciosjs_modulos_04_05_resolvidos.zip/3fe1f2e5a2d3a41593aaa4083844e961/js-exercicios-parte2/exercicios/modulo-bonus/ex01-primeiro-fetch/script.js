/*
  Módulo bônus — APIs e fetch
  Exercício 01 — Primeiro fetch
  Nível: Básico

  Objetivo: Fazer uma requisição e ver o JSON no console.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const URL_ESTADOS = "https://servicodados.ibge.gov.br/api/v1/localidades/estados";

// TODO 1: No clique, faça fetch(URL_ESTADOS), converta com .json() e mostre
//         os dados no console.
// TODO 2: Mostre também no console QUANTOS estados vieram (length).
// TODO 3: Adicione um .catch que mostra "Falha na conexão" no console.
// TESTE: desligue a internet (F12 → Network → Offline) e clique de novo.
