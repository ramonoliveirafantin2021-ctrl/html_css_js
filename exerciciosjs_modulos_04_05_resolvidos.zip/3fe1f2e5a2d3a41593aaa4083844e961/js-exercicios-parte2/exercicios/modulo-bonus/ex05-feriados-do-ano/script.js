/*
  Módulo bônus — APIs e fetch
  Exercício 05 — Feriados do ano
  Nível: Intermediário

  Objetivo: Formatar datas e destacar itens vindos de uma API.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// API: https://brasilapi.com.br/api/feriados/v1/ANO
// Cada item: { date: "2026-04-21", name: "Tiradentes", type: "national" }

// TODO 1: Busque os feriados do ano digitado.
// TODO 2: Mostre cada um como "21/04 — Tiradentes".
//         Dica: date.split("-") e monte dia/mês.
// TODO 3: Destaque com a classe "proximo" o PRIMEIRO feriado cuja data
//         ainda não passou (compare a string date com a data de hoje
//         em "AAAA-MM-DD": new Date().toISOString().slice(0, 10)).
