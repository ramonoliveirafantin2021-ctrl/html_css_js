/*
  Módulo bônus — APIs e fetch
  Exercício 02 — Assíncrono: ordem das mensagens
  Nível: Básico

  Objetivo: Entender que o fetch não trava o código.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const ordem = document.querySelector("#ordem");
const registrar = texto => ordem.innerHTML += `<li>${texto}</li>`;

// TODO 1: ANTES de rodar, escreva aqui sua previsão da ordem:
//         previsão: ...
// TODO 2: Rode e compare. Explique num comentário por que deu essa ordem.

document.querySelector("#testar").addEventListener("click", () => {
  ordem.innerHTML = "";
  registrar("A — antes do fetch");
  fetch("https://viacep.com.br/ws/01001000/json/")
    .then(r => r.json())
    .then(() => registrar("B — resposta chegou"));
  registrar("C — depois do fetch");
  setTimeout(() => registrar("D — setTimeout de 0 ms"), 0);
});
