/*
  Módulo bônus — APIs e fetch
  Exercício 08 — Reescrevendo com async/await
  Nível: Intermediário

  Objetivo: Converter um código com .then para async/await com try/catch.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// Versão com .then (funciona):
function buscarComThen() {
  fetch("https://viacep.com.br/ws/29010000/json/")
    .then(r => r.json())
    .then(dados => {
      document.querySelector("#saida").textContent = `${dados.logradouro}, ${dados.localidade}`;
    })
    .catch(() => {
      document.querySelector("#saida").textContent = "Erro!";
    });
}

// TODO 1: Escreva async function buscarComAwait() que faz a MESMA coisa
//         usando await e try/catch.
// TODO 2: Ligue o botão à versão nova.
// TODO 3: Num comentário, diga qual versão você achou mais fácil de ler e por quê.
