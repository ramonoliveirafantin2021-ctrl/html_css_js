/*
  Módulo bônus — APIs e fetch
  Exercício 09 — Ache o bug: fetch
  Nível: Desafio

  Objetivo: Corrigir erros comuns com fetch e assincronia.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO: 3 bugs. Corrija e comente cada um.
// Esperado: "27 estados" e a lista de nomes.

let estados = [];

document.querySelector("#btn").addEventListener("click", () => {
  fetch("https://servicodados.ibge.gov.br/api/v1/localidades/estados")
    .then(resposta => {
      estados = resposta;
    });

  document.querySelector("#qtd").textContent = `${estados.length} estados`;

  estados.forEach(e => {
    document.querySelector("#lista").innerHTML += `<li>${e.name}</li>`;
  });
});
