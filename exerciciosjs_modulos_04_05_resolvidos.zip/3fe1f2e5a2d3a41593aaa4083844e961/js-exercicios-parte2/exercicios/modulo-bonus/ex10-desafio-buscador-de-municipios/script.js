/*
  Módulo bônus — APIs e fetch
  Exercício 10 — Desafio: buscador de municípios
  Nível: Desafio

  Objetivo: Juntar fetch com busca ao vivo, filtros e localStorage.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// APIs:
//   estados:    https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome
//   municípios: https://servicodados.ibge.gov.br/api/v1/localidades/estados/UF/municipios

// TODO 1: Ao abrir, preencha o select com os estados (value = sigla).
// TODO 2: Ao escolher uma UF, busque os municípios, habilite a busca
//         e mostre todos.
// TODO 3: A busca filtra a lista ao vivo (evento "input"), mostrando
//         "X de Y municípios" em #info.
// TODO 4: Lembre a última UF escolhida no localStorage e já carregue ela
//         quando a página abrir.
// TODO 5: Trate erros de rede com mensagem amigável.
