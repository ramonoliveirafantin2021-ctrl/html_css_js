/*
  Módulo bônus — APIs e fetch
  Exercício 06 — Pokédex mínima
  Nível: Intermediário

  Objetivo: Montar um cartão com dados aninhados de uma API.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// API: https://pokeapi.co/api/v2/pokemon/NOME  (nome em minúsculas)
// Dados úteis: dados.name, dados.id, dados.sprites.front_default,
//              dados.types (array de { type: { name } }), dados.height, dados.weight

// TODO 1: Busque pelo nome digitado (trim + toLowerCase).
// TODO 2: Se a resposta não for ok (resposta.ok === false), mostre
//         "Não encontrado" e pare.
//         Dica: .then(r => { if (!r.ok) throw new Error("404"); return r.json(); })
// TODO 3: Monte o cartão com imagem, "#25 pikachu", tipos separados por vírgula
//         (map + join), altura em metros (height / 10) e peso em kg (weight / 10).
