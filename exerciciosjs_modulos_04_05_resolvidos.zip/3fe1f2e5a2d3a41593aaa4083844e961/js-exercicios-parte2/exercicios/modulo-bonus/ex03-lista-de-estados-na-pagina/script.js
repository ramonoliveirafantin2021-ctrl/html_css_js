/*
  Módulo bônus — APIs e fetch
  Exercício 03 — Lista de estados na página
  Nível: Básico

  Objetivo: Transformar a resposta de uma API em HTML.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

// TODO 1: Ao carregar a página, busque
//         https://servicodados.ibge.gov.br/api/v1/localidades/estados
// TODO 2: Ordene pelo nome (a.nome.localeCompare(b.nome)).
// TODO 3: Mostre "ES — Espírito Santo" (sigla — nome) em cada <li>.
// TODO 4: Troque #status para "27 estados carregados." ou "Erro ao carregar."
