# Meu progresso

Marque com `x` cada exercício concluído (troque `[ ]` por `[x]`) e faça um commit.


## Módulo 4 — Funções

- [ ] 01 — Primeira função (`exercicios/modulo-04/ex01-primeira-funcao`)
- [ ] 02 — Saudação com parâmetro (`exercicios/modulo-04/ex02-saudacao-com-parametro`)
- [ ] 03 — Calculadora de média (`exercicios/modulo-04/ex03-calculadora-de-media`)
- [ ] 04 — Conversor de temperatura (`exercicios/modulo-04/ex04-conversor-de-temperatura`)
- [ ] 05 — Formatador de preço (`exercicios/modulo-04/ex05-formatador-de-preco`)
- [ ] 06 — Desconto em cascata (`exercicios/modulo-04/ex06-desconto-em-cascata`)
- [ ] 07 — Escopo na prática (`exercicios/modulo-04/ex07-escopo-na-pratica`)
- [ ] 08 — Ache o bug: funções (`exercicios/modulo-04/ex08-ache-o-bug-funcoes`)
- [ ] 09 — Calculadora de IMC (`exercicios/modulo-04/ex09-calculadora-de-imc`)
- [ ] 10 — Desafio: painel de conversões (`exercicios/modulo-04/ex10-desafio-painel-de-conversoes`)

## Módulo 5 — Arrays e objetos

- [ ] 01 — Armários numerados (`exercicios/modulo-05/ex01-armarios-numerados`)
- [ ] 02 — Fila que anda (`exercicios/modulo-05/ex02-fila-que-anda`)
- [ ] 03 — Lista com forEach (`exercicios/modulo-05/ex03-lista-com-foreach`)
- [ ] 04 — map: transformando listas (`exercicios/modulo-05/ex04-map-transformando-listas`)
- [ ] 05 — filter e find (`exercicios/modulo-05/ex05-filter-e-find`)
- [ ] 06 — Objeto aluno (`exercicios/modulo-05/ex06-objeto-aluno`)
- [ ] 07 — Array de objetos: catálogo (`exercicios/modulo-05/ex07-array-de-objetos-catalogo`)
- [ ] 08 — Boletim com reduce (`exercicios/modulo-05/ex08-boletim-com-reduce`)
- [ ] 09 — Ache o bug: arrays e objetos (`exercicios/modulo-05/ex09-ache-o-bug-arrays-e-objetos`)
- [ ] 10 — Desafio: playlist da turma (`exercicios/modulo-05/ex10-desafio-playlist-da-turma`)

## Módulo 6 — O DOM

- [ ] 01 — Selecionando elementos (`exercicios/modulo-06/ex01-selecionando-elementos`)
- [ ] 02 — textContent x innerHTML (`exercicios/modulo-06/ex02-textcontent-x-innerhtml`)
- [ ] 03 — Trocando atributos (`exercicios/modulo-06/ex03-trocando-atributos`)
- [ ] 04 — classList: liga-desliga (`exercicios/modulo-06/ex04-classlist-liga-desliga`)
- [ ] 05 — Criando elementos (`exercicios/modulo-06/ex05-criando-elementos`)
- [ ] 06 — Removendo elementos (`exercicios/modulo-06/ex06-removendo-elementos`)
- [ ] 07 — Tabela dinâmica (`exercicios/modulo-06/ex07-tabela-dinamica`)
- [ ] 08 — Barra de progresso (`exercicios/modulo-06/ex08-barra-de-progresso`)
- [ ] 09 — Ache o bug: DOM (`exercicios/modulo-06/ex09-ache-o-bug-dom`)
- [ ] 10 — Desafio: vitrine da turma (`exercicios/modulo-06/ex10-desafio-vitrine-da-turma`)

## Módulo 7 — Eventos

- [ ] 01 — Contador de cliques (`exercicios/modulo-07/ex01-contador-de-cliques`)
- [ ] 02 — Modo escuro (`exercicios/modulo-07/ex02-modo-escuro`)
- [ ] 03 — Contador de caracteres (`exercicios/modulo-07/ex03-contador-de-caracteres`)
- [ ] 04 — Paleta de cores (`exercicios/modulo-07/ex04-paleta-de-cores`)
- [ ] 05 — Teclado: mover o personagem (`exercicios/modulo-07/ex05-teclado-mover-o-personagem`)
- [ ] 06 — Hover com mouseenter/mouseleave (`exercicios/modulo-07/ex06-hover-com-mouseenter-mouseleave`)
- [ ] 07 — Delegação: lista de compras (`exercicios/modulo-07/ex07-delegacao-lista-de-compras`)
- [ ] 08 — Ache o bug: eventos (`exercicios/modulo-07/ex08-ache-o-bug-eventos`)
- [ ] 09 — Galeria clicável (`exercicios/modulo-07/ex09-galeria-clicavel`)
- [ ] 10 — Desafio: quiz relâmpago (`exercicios/modulo-07/ex10-desafio-quiz-relampago`)

## Módulo 8 — Formulários e validação

- [ ] 01 — Lendo os campos (`exercicios/modulo-08/ex01-lendo-os-campos`)
- [ ] 02 — Campo obrigatório (`exercicios/modulo-08/ex02-campo-obrigatorio`)
- [ ] 03 — Login com regras (`exercicios/modulo-08/ex03-login-com-regras`)
- [ ] 04 — Radio e checkbox (`exercicios/modulo-08/ex04-radio-e-checkbox`)
- [ ] 05 — E-mail e idade (`exercicios/modulo-08/ex05-e-mail-e-idade`)
- [ ] 06 — Confirmar senha (`exercicios/modulo-08/ex06-confirmar-senha`)
- [ ] 07 — Força da senha (`exercicios/modulo-08/ex07-forca-da-senha`)
- [ ] 08 — Máscara de telefone e CEP (`exercicios/modulo-08/ex08-mascara-de-telefone-e-cep`)
- [ ] 09 — Ache o bug: formulários (`exercicios/modulo-08/ex09-ache-o-bug-formularios`)
- [ ] 10 — Desafio: inscrição na gincana (`exercicios/modulo-08/ex10-desafio-inscricao-na-gincana`)

## Módulo 9 — localStorage

- [ ] 01 — Primeiro contato (`exercicios/modulo-09/ex01-primeiro-contato`)
- [ ] 02 — Contador de visitas (`exercicios/modulo-09/ex02-contador-de-visitas`)
- [ ] 03 — Tema que lembra (`exercicios/modulo-09/ex03-tema-que-lembra`)
- [ ] 04 — Bloco de notas automático (`exercicios/modulo-09/ex04-bloco-de-notas-automatico`)
- [ ] 05 — Objeto com JSON (`exercicios/modulo-09/ex05-objeto-com-json`)
- [ ] 06 — Lista de favoritos (`exercicios/modulo-09/ex06-lista-de-favoritos`)
- [ ] 07 — Placar com recorde (`exercicios/modulo-09/ex07-placar-com-recorde`)
- [ ] 08 — Ache o bug: localStorage (`exercicios/modulo-09/ex08-ache-o-bug-localstorage`)
- [ ] 09 — Tarefas com filtros (`exercicios/modulo-09/ex09-tarefas-com-filtros`)
- [ ] 10 — Desafio: controle de gastos (`exercicios/modulo-09/ex10-desafio-controle-de-gastos`)

## Módulo 10 — Projeto integrador (treinos)

- [ ] 01 — Planejamento no papel (`exercicios/modulo-10/ex01-planejamento-no-papel`)
- [ ] 02 — Organizando em blocos (`exercicios/modulo-10/ex02-organizando-em-blocos`)
- [ ] 03 — Busca ao vivo (`exercicios/modulo-10/ex03-busca-ao-vivo`)
- [ ] 04 — Dois filtros combinados (`exercicios/modulo-10/ex04-dois-filtros-combinados`)
- [ ] 05 — Carrinho com quantidades (`exercicios/modulo-10/ex05-carrinho-com-quantidades`)
- [ ] 06 — Telas de um app (`exercicios/modulo-10/ex06-telas-de-um-app`)
- [ ] 07 — Datas: dias até a prova (`exercicios/modulo-10/ex07-datas-dias-ate-a-prova`)
- [ ] 08 — Roteiro de testes (`exercicios/modulo-10/ex08-roteiro-de-testes`)
- [ ] 09 — README do projeto (`exercicios/modulo-10/ex09-readme-do-projeto`)
- [ ] 10 — Desafio: jogo da memória (`exercicios/modulo-10/ex10-desafio-jogo-da-memoria`)

## Módulo bônus — APIs e fetch

- [ ] 01 — Primeiro fetch (`exercicios/modulo-bonus/ex01-primeiro-fetch`)
- [ ] 02 — Assíncrono: ordem das mensagens (`exercicios/modulo-bonus/ex02-assincrono-ordem-das-mensagens`)
- [ ] 03 — Lista de estados na página (`exercicios/modulo-bonus/ex03-lista-de-estados-na-pagina`)
- [ ] 04 — Busca de CEP (`exercicios/modulo-bonus/ex04-busca-de-cep`)
- [ ] 05 — Feriados do ano (`exercicios/modulo-bonus/ex05-feriados-do-ano`)
- [ ] 06 — Pokédex mínima (`exercicios/modulo-bonus/ex06-pokedex-minima`)
- [ ] 07 — Carregando e erro na interface (`exercicios/modulo-bonus/ex07-carregando-e-erro-na-interface`)
- [ ] 08 — Reescrevendo com async/await (`exercicios/modulo-bonus/ex08-reescrevendo-com-async-await`)
- [ ] 09 — Ache o bug: fetch (`exercicios/modulo-bonus/ex09-ache-o-bug-fetch`)
- [ ] 10 — Desafio: buscador de municípios (`exercicios/modulo-bonus/ex10-desafio-buscador-de-municipios`)
