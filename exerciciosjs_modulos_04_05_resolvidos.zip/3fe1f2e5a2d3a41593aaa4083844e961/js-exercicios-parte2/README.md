# JavaScript para Iniciantes — Parte 2 · Exercícios

Lista de exercícios dos **Módulos 4 a 10 e bônus** da apostila *JavaScript para Iniciantes*
(Curso Técnico de Informática). São **80 exercícios**, 10 por módulo, do básico ao desafio.

Cada exercício é uma pasta com três arquivos:

```
exercicios/modulo-04/ex01-primeira-funcao/
├── index.html   ← a página (normalmente você não precisa mexer)
├── script.js    ← AQUI você trabalha: siga os comentários // TODO
└── style.css    ← estilos prontos (pode alterar à vontade)
```

---

## 1. O que instalar (uma vez só)

| Ferramenta | Para quê | Onde baixar |
|---|---|---|
| **Git** | baixar e salvar versões do seu código | https://git-scm.com/downloads |
| **VS Code** | editor de código | https://code.visualstudio.com |
| **Node.js (versão LTS)** | rodar o `npx live-server` (só para o Caminho B) | https://nodejs.org |
| **Navegador** | Chrome, Edge ou Firefox, com o DevTools (F12) | — |

Confira no terminal se deu certo:

```bash
git --version
node --version   # só se for usar o Caminho B
```

Se for a primeira vez usando Git neste computador, configure seu nome e e-mail:

```bash
git config --global user.name "Seu Nome"
git config --global user.email "seu-email@exemplo.com"
```

---

## 2. Pegue a sua cópia do repositório

1. Entre no GitHub com a sua conta.
2. Nesta página do repositório, clique em **Fork** (canto superior direito) e depois em **Create fork**.
   Agora você tem uma cópia **sua**, em `github.com/SEU-USUARIO/js-exercicios-parte2`.
3. Na **sua** cópia, clique no botão verde **Code** e copie o endereço HTTPS.
4. No terminal, dentro da pasta onde você guarda seus projetos:

```bash
git clone https://github.com/SEU-USUARIO/js-exercicios-parte2.git
cd js-exercicios-parte2
code .
```

> O comando `code .` abre a pasta no VS Code. Se não funcionar, abra o VS Code e use
> **File → Open Folder** (Arquivo → Abrir Pasta) e escolha a pasta `js-exercicios-parte2`.

---

## 3. Rode o servidor local

Por que não dar dois cliques no `index.html`? Porque alguns exercícios (os do módulo bônus, com `fetch`)
precisam de um servidor, e o servidor ainda **recarrega a página sozinho** toda vez que você salva. Escolha
**um** dos dois caminhos.

### Caminho A — Extensão Live Server do VS Code (mais simples)

1. Ao abrir a pasta, o VS Code mostra um aviso sugerindo extensões recomendadas. Clique em **Install**.
   Se o aviso não aparecer: abra a aba **Extensions** (`Ctrl+Shift+X`), procure **Live Server**
   (autor: *Ritwick Dey*) e instale.
2. Clique em **Go Live** na barra azul, lá embaixo à direita.
   (Ou clique com o botão direito no `index.html` → **Open with Live Server**.)
3. O navegador abre em `http://127.0.0.1:5500` com a lista de exercícios.

Para parar: clique de novo no botão (agora escrito **Port: 5500**).

### Caminho B — Terminal com `npx live-server`

No terminal do VS Code (`` Ctrl+` ``), dentro da pasta do repositório:

```bash
npx live-server --port=5500
```

Na primeira vez ele pergunta se pode baixar o pacote: responda `y`. O navegador abre sozinho.

Prefere instalar uma vez e usar um comando curto?

```bash
npm install     # baixa o live-server para a pasta node_modules (uma vez só)
npm start       # liga o servidor e abre a lista de exercícios
```

Para parar o servidor: `Ctrl+C` no terminal.

---

## 4. Como fazer cada exercício

1. Na lista que abriu no navegador, clique no exercício.
2. No VS Code, abra o `script.js` daquela pasta. O comentário do topo diz o **objetivo** e o **nível**.
3. Resolva os `// TODO` **um de cada vez**. Salve (`Ctrl+S`) e olhe o navegador a cada passo.
4. Deixe o **console aberto** (`F12` → aba *Console*). Erro vermelho não é vergonha: leia, ele diz a linha!
5. Terminou? Marque o exercício no arquivo [`PROGRESSO.md`](PROGRESSO.md) e salve seu trabalho no GitHub:

```bash
git add .
git commit -m "Módulo 4 - exercício 01 concluído"
git push
```

> Dica: faça um commit **por exercício**. Assim o professor (e você) consegue ver a evolução.

---

## 5. Organização

| Pasta | Conteúdo | Exercícios |
|---|---|---|
| `exercicios/modulo-04` | Funções | 10 |
| `exercicios/modulo-05` | Arrays e objetos | 10 |
| `exercicios/modulo-06` | O DOM | 10 |
| `exercicios/modulo-07` | Eventos | 10 |
| `exercicios/modulo-08` | Formulários e validação | 10 |
| `exercicios/modulo-09` | `localStorage` | 10 |
| `exercicios/modulo-10` | Treinos para o projeto integrador | 10 |
| `exercicios/modulo-bonus` | APIs e `fetch` | 10 |
| `docs/apostila-parte2.md` | A apostila completa, para consulta | — |

Em cada módulo: exercícios **01–04** são básicos, **05–08** intermediários (inclui um *Ache o bug*)
e **09–10** são desafios (o 10 é o mini-projeto do módulo).

---

## 6. Recebendo exercícios novos do professor

Quando o professor atualizar o repositório original, entre na **sua** cópia no GitHub e clique em
**Sync fork → Update branch**. Depois, no seu computador:

```bash
git pull
```

---

## 7. Deu problema?

| Sintoma | Provável causa | Solução |
|---|---|---|
| `git` ou `node` "não é reconhecido como comando" | não instalado, ou terminal aberto antes da instalação | instale e **feche e abra** o terminal / VS Code |
| `npx` pede permissão em loop ou dá erro de rede | proxy/firewall da escola | use o **Caminho A** (extensão Live Server) |
| "Porta 5500 em uso" | já existe um servidor ligado | feche o outro (`Ctrl+C` ou botão *Port: 5500*) ou use `--port=5501` |
| A página não atualiza ao salvar | abriu o arquivo direto (endereço começa com `file://`) | abra pelo servidor (`http://127.0.0.1:5500`) |
| `Cannot set properties of null` no console | seletor errado ou falta `defer` no `<script>` | releia o Módulo 6, seção 6.2 |
| No PowerShell: "execução de scripts foi desabilitada" ao rodar `npx` | política de segurança do Windows | no terminal do VS Code, troque o perfil para **Command Prompt** ou **Git Bash** |
| Exercícios do bônus não carregam dados | sem internet ou API bloqueada na rede da escola | teste a URL da API direto no navegador |
