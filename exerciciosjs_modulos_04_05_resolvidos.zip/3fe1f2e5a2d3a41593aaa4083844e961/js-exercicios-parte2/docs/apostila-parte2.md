# JavaScript para Iniciantes — Parte 2
### Funções, dados, DOM, eventos, formulários e persistência: a página que pensa, reage e lembra

*Curso Técnico de Informática — Módulo integrado a HTML & CSS*

---

## Antes de começar: onde a gente parou

Na Parte 1 você aprendeu a guardar valores em variáveis, tomar decisões com `if` e repetir tarefas com `for` e `while`. Isso já é programação de verdade. Mas, se você reparar bem, todo o código que escrevemos até agora era um grande bloco **corrido**, de cima para baixo, rodando uma vez só quando a página carrega.

A Parte 2 muda o jogo em três sentidos:

1. **Organização** — você vai aprender a quebrar o código em pedaços com nome (funções) e a guardar dados de forma estruturada (arrays e objetos).
2. **Conversa com o HTML** — o JavaScript vai deixar de só "escrever no console" e vai passar a mexer na página de verdade: criar, apagar, trocar, esconder e mostrar elementos (DOM).
3. **Reação e memória** — a página vai responder ao usuário (eventos e formulários) e vai lembrar das coisas mesmo depois de fechar o navegador (`localStorage`).

No fim, você vai ter tudo o que precisa para construir uma aplicação pequena, mas completa — e é exatamente isso que o Módulo 10 vai te pedir.

### Os ícones de sempre (e dois novos)

- 🗣️ **Não existe pergunta boba** — as dúvidas que todo mundo tem.
- 🏋️ **Academia de exercícios** — mão na massa, dentro do capítulo.
- 🐞 **Ache o bug** — código com erro proposital. Tente achar **antes** de ler a resposta.
- 🧠 **Confira sua memória** — revisão rápida no fim do capítulo.
- 🎬 **Nos bastidores** — curiosidades e o "porquê" das coisas.
- 🔴 **Lendo o console** — *novo!* Uma mensagem de erro real, traduzida linha por linha.
- ✏️ **Aponte seu lápis** — *novo!* Antes de rodar o código, **preveja** o que vai sair. Escreva no caderno. Depois confira. Errar a previsão é ótimo: é exatamente aí que o cérebro aprende.

### Kit de trabalho

Todos os exemplos desta apostila usam a mesma estrutura de pasta da Parte 1:

```
minha-pasta/
├── index.html
├── style.css      (quando precisar)
└── script.js
```

E o mesmo esqueleto de HTML. Guarde este modelo, você vai copiar ele dezenas de vezes:

```html
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Exemplo</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js" defer></script>
</head>
<body>
  <!-- o conteúdo de cada exemplo entra aqui -->
</body>
</html>
```

> Repare que o `<script>` está no `<head>` **com `defer`**. Lembra do Módulo 0? O `defer` faz o navegador esperar o HTML inteiro carregar antes de rodar o script. Assim, quando o JavaScript procurar um elemento, ele já existe.

Junto com esta apostila, você recebe uma **lista de exercícios** com 10 atividades por módulo. Cada exercício é uma pasta pronta com `index.html`, `script.js` e (quando precisa) `style.css`. Os comentários `// TODO` dentro do `script.js` dizem exatamente o que você deve fazer.

### Sumário

- Módulo 4 — Funções: organizando o código
- Módulo 5 — Arrays e objetos: organizando dados
- Módulo 6 — O DOM: JavaScript conversando com o HTML
- Módulo 7 — Eventos: a página que reage
- Módulo 8 — Formulários e validação
- Módulo 9 — Guardando dados: `localStorage`
- Módulo 10 — Projeto integrador final
- Módulo bônus — Primeiros passos além do navegador

Bora?

---
## Módulo 4 — Funções: organizando o código

> *"Se você copiou e colou o mesmo código três vezes, você tem três bugs esperando para acontecer."*

### 4.1 O problema: o código "copia-e-cola"

Olha esse script. Ele mostra a média de três alunos na página:

```js
// Aluno 1
const notaA1 = 7, notaA2 = 8, notaA3 = 6;
const mediaA = (notaA1 + notaA2 + notaA3) / 3;
console.log(`Ana: ${mediaA.toFixed(1)}`);

// Aluno 2
const notaB1 = 5, notaB2 = 6, notaB3 = 4;
const mediaB = (notaB1 + notaB2 + notaB3) / 3;
console.log(`Bruno: ${mediaB.toFixed(1)}`);

// Aluno 3
const notaC1 = 9, notaC2 = 9, notaC3 = 10;
const mediaC = (notaC1 + notaC2 + notaC3) / 3;
console.log(`Carla: ${mediaC.toFixed(1)}`);
```

Funciona. Agora imagine que a coordenação decidiu que a **terceira nota vale peso 2**. Você vai precisar mudar a fórmula em três lugares. Se esquecer de um, o boletim de alguém sai errado — e ninguém percebe até o conselho de classe.

O problema não é a conta. É a **repetição**. E a ferramenta que resolve repetição de *lógica* (não de valores) chama-se **função**.

### 4.2 Função é uma receita

Pense numa receita de bolo:

| Receita de bolo | Função em JavaScript |
|---|---|
| Nome: "Bolo de cenoura" | `function calcularMedia` |
| Ingredientes: cenoura, ovos, farinha | parâmetros: `(n1, n2, n3)` |
| Modo de preparo | o corpo `{ ... }` |
| O bolo pronto que sai do forno | o `return` |
| "Faz aquele bolo de cenoura pra mim?" | a chamada: `calcularMedia(7, 8, 6)` |

Escrever a receita **não** faz bolo nenhum. Só quando alguém **usa** a receita é que o bolo sai. Com funções é igual: **declarar** a função não executa nada; **chamar** a função é que executa.

Reescrevendo o exemplo:

```js
function calcularMedia(n1, n2, n3) {
  return (n1 + n2 + n3) / 3;
}

console.log(`Ana: ${calcularMedia(7, 8, 6).toFixed(1)}`);
console.log(`Bruno: ${calcularMedia(5, 6, 4).toFixed(1)}`);
console.log(`Carla: ${calcularMedia(9, 9, 10).toFixed(1)}`);
```

E se a terceira nota passar a valer peso 2? **Uma** linha muda:

```js
function calcularMedia(n1, n2, n3) {
  return (n1 + n2 + n3 * 2) / 4;
}
```

Os três alunos são corrigidos de uma vez. Isso é o superpoder da função.

### 4.3 Anatomia de uma função

```js
function saudar(nome, periodo) {      // 1. palavra-chave, nome e parâmetros
  const frase = `Bom ${periodo}, ${nome}!`; // 2. corpo
  return frase;                       // 3. valor devolvido
}

const mensagem = saudar("Ana", "dia"); // 4. chamada com argumentos
console.log(mensagem);                 // Bom dia, Ana!
```

1. **`function`** avisa o JavaScript que vem uma função. **`saudar`** é o nome (use verbos: `calcular`, `mostrar`, `validar`, `criar`). **`nome, periodo`** são os **parâmetros**: variáveis que só existem dentro da função.
2. O **corpo** é o passo a passo entre `{ }`.
3. **`return`** devolve um valor para quem chamou e **encerra** a função.
4. Na **chamada**, os valores que você passa (`"Ana"`, `"dia"`) se chamam **argumentos**. Eles entram nos parâmetros **pela ordem**: o primeiro argumento vai para o primeiro parâmetro, e assim por diante.

### ✏️ Aponte seu lápis

Preveja a saída de cada linha antes de rodar:

```js
function dobro(x) {
  return x * 2;
}

console.log(dobro(4));
console.log(dobro(dobro(3)));
console.log(dobro("5"));
console.log(dobro());
```

<details><summary>Resposta</summary>

- `8`
- `12` — primeiro `dobro(3)` vira `6`, depois `dobro(6)` vira `12`. Funções podem receber o resultado de outras funções.
- `10` — o `*` converte a string `"5"` em número (o `+` não faria isso!).
- `NaN` — sem argumento, `x` é `undefined`, e `undefined * 2` é *Not a Number*.

</details>

### 4.4 Parâmetros: a ordem importa

```js
function apresentar(nome, idade) {
  return `${nome} tem ${idade} anos.`;
}

console.log(apresentar("Léo", 17)); // Léo tem 17 anos.
console.log(apresentar(17, "Léo")); // 17 tem Léo anos.  😬
```

O JavaScript não "adivinha" qual argumento é qual. Ele só segue a ordem.

#### Valores padrão

Você pode dar um valor padrão para um parâmetro, usado quando o argumento não vem:

```js
function saudar(nome = "visitante") {
  return `Olá, ${nome}!`;
}

console.log(saudar("Bia")); // Olá, Bia!
console.log(saudar());      // Olá, visitante!
```

Isso é muito útil para evitar o famoso `undefined` aparecendo no meio da página.

### 4.5 `return`: devolver é diferente de mostrar

Este é o ponto que mais confunde quem está começando. Compare:

```js
function somarMostrando(a, b) {
  console.log(a + b);
}

function somarDevolvendo(a, b) {
  return a + b;
}

const r1 = somarMostrando(2, 3);  // aparece 5 no console...
const r2 = somarDevolvendo(2, 3); // não aparece nada...

console.log(r1); // undefined  ← a função não devolveu nada!
console.log(r2); // 5
```

Analogia: `console.log` é **falar em voz alta** o resultado. `return` é **entregar o resultado na mão** de quem pediu. Se você só falou, a pessoa ouviu, mas não tem nada na mão para usar depois.

Regra prática: **funções que calculam devem usar `return`**. Deixe o `console.log` (ou a escrita na página) para quem chama.

#### O `return` encerra a função

```js
function classificar(nota) {
  if (nota >= 6) {
    return "Aprovado";
  }
  return "Reprovado"; // só chega aqui se o if acima for falso
}

console.log(classificar(8)); // Aprovado
console.log(classificar(3)); // Reprovado
```

Repare que não precisou de `else`: quando a nota é 8, o primeiro `return` já encerra a função, e a linha de baixo nunca roda. Esse padrão se chama **retorno antecipado** e deixa o código mais limpo.

### 🗣️ Não existe pergunta boba

**"Posso ter mais de um `return` na mesma função?"**
Pode, desde que estejam em caminhos diferentes (dentro de `if`s diferentes, por exemplo). Só **um** deles vai ser executado em cada chamada, porque o primeiro que rodar encerra a função.

**"Uma função pode devolver mais de um valor?"**
Diretamente, não. Mas ela pode devolver um **array** ou um **objeto** com vários valores dentro — você vai ver isso no Módulo 5.

**"Posso chamar a função antes de escrevê-la no código?"**
Com `function nome() {}`, sim — o JavaScript "lê" essas declarações antes de executar o arquivo (isso se chama *hoisting*). Com arrow functions guardadas em `const`, não. Para evitar confusão, nesta apostila vamos sempre **declarar primeiro e chamar depois**.

### 4.6 Arrow functions: o atalho moderno

A partir de 2015 (ES6), surgiu uma forma mais curta de escrever funções. Veja a mesma função escrita de quatro jeitos:

```js
// 1. Declaração tradicional
function quadrado(n) {
  return n * n;
}

// 2. Arrow function com corpo
const quadrado2 = (n) => {
  return n * n;
};

// 3. Arrow function de uma linha (return implícito)
const quadrado3 = (n) => n * n;

// 4. Com um único parâmetro, os parênteses são opcionais
const quadrado4 = n => n * n;
```

Todas fazem a mesma coisa. Algumas regras do formato curto:

| Situação | Exemplo |
|---|---|
| Nenhum parâmetro | `const ola = () => "Olá!";` |
| Um parâmetro | `const dobro = n => n * 2;` |
| Dois ou mais | `const somar = (a, b) => a + b;` |
| Corpo com várias linhas | `const f = (a) => { const x = a * 2; return x + 1; };` |

> ⚠️ Atenção: quando você abre `{ }` numa arrow function, o `return` deixa de ser automático. `const f = n => { n * 2 };` devolve `undefined`!

**Quando usar cada uma?** Nesta apostila: `function` para as funções "principais" do seu programa (`renderizarLista`, `validarFormulario`) e arrow functions para funções curtas que vão **dentro** de outras coisas (`forEach`, `map`, `addEventListener`). É um estilo comum no mercado, mas não é lei.

### 🎬 Nos bastidores — funções são valores

Em JavaScript, uma função é um **valor**, igual a um número ou uma string. Isso significa que você pode guardar uma função numa variável (é o que a arrow function faz), passar uma função como argumento de outra, e até devolver uma função. Parece estranho agora, mas é exatamente isso que está acontecendo quando você escreve `botao.addEventListener("click", minhaFuncao)`: você está **entregando a receita** para o navegador usar depois, quando o clique acontecer. Guarde essa ideia: ela volta com força nos Módulos 5 e 7.

### 4.7 Escopo: quem enxerga o quê

**Escopo** é a "área" do código onde uma variável existe.

Imagine a escola. O **pátio** é o escopo global: todo mundo vê o que está lá. Cada **sala de aula** é o escopo de uma função: o que está escrito no quadro da sala 3 não aparece no pátio. Mas, de dentro da sala, dá para ver o pátio pela janela.

```js
const escola = "ETEC Central"; // pátio (global)

function salaDeAula() {
  const quadro = "Hoje: funções"; // só existe dentro da sala
  console.log(escola); // ✅ de dentro da sala, enxerga o pátio
  console.log(quadro); // ✅
}

salaDeAula();
console.log(escola); // ✅
console.log(quadro); // ❌ ReferenceError: quadro is not defined
```

E isso vale para **qualquer** bloco `{ }` com `let` e `const`, não só funções:

```js
const idade = 20;

if (idade >= 18) {
  const mensagem = "Maior de idade";
  console.log(mensagem); // ✅
}

console.log(mensagem); // ❌ ReferenceError
```

#### Por que o escopo é uma coisa boa

Parece uma limitação, mas é proteção. Duas funções diferentes podem ter uma variável chamada `resultado` sem uma atrapalhar a outra:

```js
function calcularArea(l) {
  const resultado = l * l;
  return resultado;
}

function calcularPerimetro(l) {
  const resultado = l * 4; // outro "resultado", em outra sala
  return resultado;
}
```

### 🔴 Lendo o console

```
Uncaught ReferenceError: quadro is not defined
    at script.js:12:13
```

- **`Uncaught`** — o erro não foi tratado e parou o script.
- **`ReferenceError`** — você se referiu a um nome que o JavaScript não conhece **naquele lugar**.
- **`quadro is not defined`** — o nome do culpado.
- **`script.js:12:13`** — arquivo, **linha 12**, coluna 13. Clique nesse link no DevTools e ele te leva direto para a linha.

Quando aparecer um `ReferenceError`, faça duas perguntas: *"escrevi o nome igualzinho (maiúsculas contam!)?"* e *"essa variável foi criada dentro de outro bloco?"*.

### 4.8 Funções que mexem na página

Até aqui, nossas funções só calculavam. Agora vamos ligar uma função a um botão — uma prévia do Módulo 7.

`index.html`:
```html
<h1>Calculadora de média</h1>
<p>Notas: 7, 8 e 6</p>
<button id="btnCalcular">Calcular média</button>
<p id="resultado"></p>
```

`script.js`:
```js
function calcularMedia(n1, n2, n3) {
  return (n1 + n2 + n3) / 3;
}

function mostrarResultado() {
  const media = calcularMedia(7, 8, 6);
  const situacao = media >= 6 ? "Aprovado(a)" : "Reprovado(a)";
  document.querySelector("#resultado").textContent =
    `Média ${media.toFixed(1)} — ${situacao}`;
}

document.querySelector("#btnCalcular").addEventListener("click", mostrarResultado);
```

Repare na **divisão de tarefas**: `calcularMedia` só calcula (não sabe que existe uma página); `mostrarResultado` cuida da página. Separar "calcular" de "mostrar" é um dos hábitos mais valiosos que você pode criar agora.

### 4.9 Exemplos para estudar

**Conversor de temperatura**

```js
const celsiusParaFahrenheit = (c) => c * 9 / 5 + 32;

console.log(celsiusParaFahrenheit(0));   // 32
console.log(celsiusParaFahrenheit(100)); // 212
console.log(celsiusParaFahrenheit(37));  // 98.6
```

**Formatador de preço** (você vai usar muito nos catálogos)

```js
function formatarPreco(valor) {
  return `R$ ${valor.toFixed(2).replace(".", ",")}`;
}

console.log(formatarPreco(19.9)); // R$ 19,90
console.log(formatarPreco(5));    // R$ 5,00
```

**Função que usa outra função**

```js
function calcularIMC(peso, altura) {
  return peso / (altura * altura);
}

function classificarIMC(imc) {
  if (imc < 18.5) return "Abaixo do peso";
  if (imc < 25) return "Peso normal";
  if (imc < 30) return "Sobrepeso";
  return "Obesidade";
}

function relatorioIMC(nome, peso, altura) {
  const imc = calcularIMC(peso, altura);
  return `${nome}: IMC ${imc.toFixed(1)} (${classificarIMC(imc)})`;
}

console.log(relatorioIMC("Ana", 60, 1.65));
console.log(relatorioIMC("Léo", 85, 1.75));
```

Cada função faz **uma** coisa só. Quando uma função começa a fazer coisas demais, quebre em funções menores.

### 🐞 Ache o bug #1

```js
function calcularDesconto(preco, porcentagem) {
  const desconto = preco * porcentagem / 100;
  preco - desconto;
}

console.log(calcularDesconto(100, 10));
```

<details><summary>Resposta</summary>

Sai `undefined`. A conta `preco - desconto` é feita, mas o resultado não vai para lugar nenhum. Falta o `return`: `return preco - desconto;`.

</details>

### 🐞 Ache o bug #2

```js
const somar = (a, b) => { a + b };
console.log(somar(2, 3));
```

<details><summary>Resposta</summary>

Sai `undefined`. Ao abrir `{ }`, a arrow function perde o `return` automático. Duas correções possíveis: `(a, b) => a + b` (sem chaves) ou `(a, b) => { return a + b; }`.

</details>

### 🐞 Ache o bug #3

```js
function contarCliques() {
  let cliques = 0;
  cliques = cliques + 1;
  console.log(cliques);
}

contarCliques();
contarCliques();
contarCliques();
```

O programador esperava ver `1`, `2`, `3`. Viu `1`, `1`, `1`. Por quê?

<details><summary>Resposta</summary>

Escopo! `cliques` é criada **dentro** da função, então a cada chamada nasce uma variável nova, valendo `0`. Para o valor "sobreviver" entre chamadas, a variável precisa estar **fora** da função: `let cliques = 0;` antes do `function`.

</details>

### 🏋️ Academia de exercícios

1. Escreva `ehMaiorDeIdade(idade)` que devolve `true` ou `false`.
2. Escreva `areaCirculo(raio)` usando `Math.PI`.
3. Escreva `saudacaoPorHorario(hora)` que devolve "Bom dia" (0–11), "Boa tarde" (12–17) ou "Boa noite" (18–23).
4. Reescreva os três exercícios acima como arrow functions.
5. Escreva `maior(a, b)` sem usar `Math.max`.

### 🧠 Confira sua memória

1. Qual a diferença entre **parâmetro** e **argumento**?
2. O que acontece com as linhas de uma função que vêm **depois** de um `return` executado?
3. Quando uma arrow function tem `return` automático?
4. Por que uma variável criada dentro de uma função não pode ser usada fora dela?
5. Por que é boa ideia separar a função que **calcula** da função que **mostra** na página?

### Mini-projeto do módulo: "Painel de conversões"

Uma página com três botões: *Celsius → Fahrenheit*, *Km → Milhas* e *Reais → Dólar* (use uma cotação fixa numa `const`). Cada botão chama uma função que mostra o resultado de um valor fixo num `<p>`. Exigências: uma função de **cálculo** por conversão (com `return`), e uma função de **exibição** reutilizada pelas três.

---
## Módulo 5 — Arrays e objetos: organizando dados

> *"Variável guarda uma coisa. Array guarda uma fila de coisas. Objeto guarda uma coisa com várias características. Juntos, eles guardam o mundo."*

### 5.1 O problema: variável demais

Imagine uma loja com cinco produtos:

```js
const produto1 = "Caderno";
const produto2 = "Caneta";
const produto3 = "Mochila";
const produto4 = "Estojo";
const produto5 = "Régua";
```

E se forem 200 produtos? E se o número mudar todo dia? Precisamos de **uma** variável que guarde **vários** valores. Isso é um **array**.

### 5.2 Arrays: uma fila numerada

```js
const produtos = ["Caderno", "Caneta", "Mochila", "Estojo", "Régua"];
```

Pense num array como os armários numerados do vestiário. Cada armário tem um **número** (índice) e guarda **uma** coisa. E, como você viu no Módulo 3, a numeração começa no **zero**:

| Índice | 0 | 1 | 2 | 3 | 4 |
|---|---|---|---|---|---|
| Valor | "Caderno" | "Caneta" | "Mochila" | "Estojo" | "Régua" |

```js
console.log(produtos[0]);       // "Caderno"
console.log(produtos[2]);       // "Mochila"
console.log(produtos.length);   // 5
console.log(produtos[produtos.length - 1]); // "Régua" — o último, sempre
console.log(produtos[10]);      // undefined — armário que não existe
```

#### Alterando um item

```js
const notas = [7, 5, 9];
notas[1] = 6;           // troca o 5 por 6
console.log(notas);     // [7, 6, 9]
```

### 🗣️ Não existe pergunta boba

**"Se o array é `const`, como eu consegui mudar um item?"**
Ótima pergunta. `const` impede que a **variável** aponte para outro array (`notas = [1, 2]` dá erro). Mas o **conteúdo** do array pode mudar. É como uma estante pregada na parede: você não pode trocar de estante, mas pode trocar os livros dela.

**"Um array pode misturar tipos?"**
Pode (`["Ana", 16, true]`), mas evite. Arrays funcionam melhor quando todos os itens são do mesmo "tipo de coisa": todos nomes, todos números, todos produtos.

### 5.3 Os métodos do dia a dia

**Adicionar e remover nas pontas**

```js
const fila = ["Ana", "Bruno"];

fila.push("Carla");     // adiciona no FIM      → ["Ana", "Bruno", "Carla"]
fila.unshift("Davi");   // adiciona no INÍCIO   → ["Davi", "Ana", "Bruno", "Carla"]
fila.pop();             // remove do FIM        → ["Davi", "Ana", "Bruno"]
fila.shift();           // remove do INÍCIO     → ["Ana", "Bruno"]
```

Truque para lembrar: **push/pop** mexem no fim (como uma pilha de pratos); **unshift/shift** mexem no começo.

**Procurar**

```js
const frutas = ["maçã", "banana", "uva"];

console.log(frutas.includes("uva"));    // true
console.log(frutas.includes("manga"));  // false
console.log(frutas.indexOf("banana"));  // 1
console.log(frutas.indexOf("manga"));   // -1  (não achou)
```

**Remover do meio: `splice`**

```js
const tarefas = ["Lavar louça", "Estudar JS", "Arrumar quarto"];
tarefas.splice(1, 1); // a partir do índice 1, remove 1 item
console.log(tarefas); // ["Lavar louça", "Arrumar quarto"]
```

**Juntar em texto: `join`**

```js
const ingredientes = ["farinha", "ovos", "leite"];
console.log(ingredientes.join(", ")); // "farinha, ovos, leite"
```

### 5.4 Percorrendo arrays: `for`, `for...of` e `forEach`

Três jeitos de passar por todos os itens, do mais "manual" ao mais direto:

```js
const cores = ["vermelho", "verde", "azul"];

// 1. for clássico (Módulo 3) — você controla o índice
for (let i = 0; i < cores.length; i++) {
  console.log(i, cores[i]);
}

// 2. for...of — direto nos valores
for (const cor of cores) {
  console.log(cor);
}

// 3. forEach — o array chama uma função para cada item
cores.forEach((cor, indice) => {
  console.log(`${indice + 1}ª cor: ${cor}`);
});
```

Lembra do *"funções são valores"* do Módulo 4? No `forEach` você **entrega uma função** ao array, e ele chama essa função uma vez para cada item, passando o item (e, se você quiser, o índice).

### 5.5 `map`, `filter`, `find` e `reduce`: as ferramentas de transformação

Esses métodos **não mexem** no array original. Eles devolvem um resultado **novo**.

**`map` — transformar cada item** (mesma quantidade de itens)

```js
const precos = [10, 25, 40];
const comAumento = precos.map(p => p * 1.1);
console.log(comAumento); // [11, 27.5, 44]

const nomes = ["ana", "léo"];
const maiusculos = nomes.map(n => n.toUpperCase());
console.log(maiusculos); // ["ANA", "LÉO"]
```

**`filter` — ficar só com alguns** (mesma ou menor quantidade)

```js
const notas = [4, 7, 9, 5, 6];
const aprovadas = notas.filter(n => n >= 6);
console.log(aprovadas); // [7, 9, 6]
```

**`find` — achar o primeiro que bate** (um item só, ou `undefined`)

```js
const idades = [12, 15, 19, 22];
const primeiroAdulto = idades.find(i => i >= 18);
console.log(primeiroAdulto); // 19
```

**`reduce` — juntar tudo num valor só** (introdução)

```js
const carrinho = [30, 15, 55];
const total = carrinho.reduce((soma, preco) => soma + preco, 0);
console.log(total); // 100
```

Leia o `reduce` assim: *"começa com `soma = 0`; para cada `preco`, a nova soma é `soma + preco`"*. Se ficou confuso, tudo bem: dá para fazer a mesma coisa com `forEach` e uma variável `let total = 0`. Use o que você entende.

#### Resumo visual

| Método | Pergunta que responde | Devolve |
|---|---|---|
| `forEach` | "Faça algo com cada um" | nada (`undefined`) |
| `map` | "Transforme cada um" | array do **mesmo** tamanho |
| `filter` | "Quais passam no teste?" | array **igual ou menor** |
| `find` | "Qual é o primeiro que passa?" | **um** item ou `undefined` |
| `reduce` | "Junte tudo em um valor" | **um** valor |

### ✏️ Aponte seu lápis

```js
const numeros = [1, 2, 3, 4, 5, 6];

const a = numeros.filter(n => n % 2 === 0);
const b = numeros.map(n => n * 10);
const c = numeros.find(n => n > 3);
const d = numeros.filter(n => n > 10);
const e = numeros.filter(n => n % 2 === 0).map(n => n * n);
```

<details><summary>Resposta</summary>

- `a` → `[2, 4, 6]`
- `b` → `[10, 20, 30, 40, 50, 60]`
- `c` → `4`
- `d` → `[]` (array vazio, **não** `undefined`)
- `e` → `[4, 16, 36]` (primeiro filtra os pares, depois eleva ao quadrado)

</details>

### 5.6 Objetos: uma coisa, várias características

Um array responde *"quais são os produtos?"*. Mas e se eu quiser saber o **preço** e a **categoria** de um produto? Para descrever **uma coisa** com várias características, usamos um **objeto**:

```js
const produto = {
  nome: "Mochila",
  preco: 149.9,
  categoria: "acessórios",
  emEstoque: true
};
```

Pense numa **ficha de cadastro**: cada linha tem um rótulo (a **chave**) e uma resposta (o **valor**).

**Lendo**

```js
console.log(produto.nome);        // "Mochila" — notação de ponto
console.log(produto["preco"]);    // 149.9     — notação de colchetes
console.log(produto.cor);         // undefined — chave que não existe
```

**Alterando e adicionando**

```js
produto.preco = 129.9;        // altera
produto.cor = "preta";        // adiciona uma chave nova
delete produto.emEstoque;     // remove uma chave
```

**Quando usar colchetes?** Quando o nome da chave está guardado numa variável:

```js
const campo = "categoria";
console.log(produto[campo]); // "acessórios"
console.log(produto.campo);  // undefined (procura uma chave chamada "campo")
```

#### Métodos: funções dentro de objetos

```js
const contaBancaria = {
  titular: "Ana",
  saldo: 100,
  depositar(valor) {
    this.saldo = this.saldo + valor;
  },
  extrato() {
    return `${this.titular}: R$ ${this.saldo.toFixed(2)}`;
  }
};

contaBancaria.depositar(50);
console.log(contaBancaria.extrato()); // Ana: R$ 150.00
```

Dentro de um método, **`this`** significa "este objeto aqui". `this.saldo` é o saldo **desta** conta.

#### Percorrendo as chaves de um objeto

```js
const aluno = { nome: "Bia", turma: "2º Info", nota: 8.5 };

for (const chave in aluno) {
  console.log(`${chave}: ${aluno[chave]}`);
}
// nome: Bia
// turma: 2º Info
// nota: 8.5

console.log(Object.keys(aluno));   // ["nome", "turma", "nota"]
console.log(Object.values(aluno)); // ["Bia", "2º Info", 8.5]
```

### 🗣️ Não existe pergunta boba

**"Quando uso array e quando uso objeto?"**
Pergunte-se: *"isso é uma **lista** de coisas parecidas, ou **uma** coisa com várias informações?"* Lista de alunos → array. Um aluno com nome, nota e turma → objeto. Lista de alunos, cada um com nome, nota e turma → **array de objetos** (próxima seção!).

**"`{}` não é o mesmo símbolo do bloco do `if`?"**
É o mesmo símbolo, mas em contextos diferentes. Depois de `if (...)`, `for (...)` ou `function`, as chaves abrem um **bloco de código**. Depois de `=` ou dentro de um array, abrem um **objeto**.

### 5.7 Arrays de objetos: o formato dos dados reais

Praticamente todo dado que um site mostra — produtos, posts, mensagens, músicas — chega neste formato:

```js
const alunos = [
  { nome: "Ana",   nota: 8.5, turma: "A" },
  { nome: "Bruno", nota: 5.0, turma: "B" },
  { nome: "Carla", nota: 9.5, turma: "A" },
  { nome: "Davi",  nota: 6.0, turma: "B" }
];

console.log(alunos[2].nome);   // "Carla"
console.log(alunos.length);    // 4
```

Agora todas as ferramentas da seção 5.5 ficam poderosas de verdade:

```js
// Quem passou?
const aprovados = alunos.filter(a => a.nota >= 6);

// Só os nomes
const nomes = alunos.map(a => a.nome);                // ["Ana", "Bruno", "Carla", "Davi"]

// Alunos da turma A
const turmaA = alunos.filter(a => a.turma === "A");

// Encontrar o Davi
const davi = alunos.find(a => a.nome === "Davi");

// Média da turma
const soma = alunos.reduce((total, a) => total + a.nota, 0);
const media = soma / alunos.length;                   // 7.25

// Nomes dos aprovados, numa frase
const frase = alunos
  .filter(a => a.nota >= 6)
  .map(a => a.nome)
  .join(", ");
console.log(`Aprovados: ${frase}`);                   // Aprovados: Ana, Carla, Davi
```

Leia a última linha em voz alta: *"pegue os alunos, filtre os que têm nota maior ou igual a 6, transforme cada um no seu nome, e junte com vírgula"*. Isso é código **declarativo**: diz **o que** você quer, não **como** fazer passo a passo.

#### Ordenando

```js
const porNota = [...alunos].sort((a, b) => b.nota - a.nota);
console.log(porNota.map(a => a.nome)); // ["Carla", "Ana", "Davi", "Bruno"]
```

`sort` recebe uma função que compara dois itens. `b.nota - a.nota` ordena do maior para o menor (troque para `a.nota - b.nota` para o contrário). O `[...alunos]` cria uma **cópia** antes de ordenar, porque `sort` **altera** o array original.

### 5.8 Do array para a página: renderizando cartões

`index.html`:
```html
<h1>Cantina da Escola</h1>
<div id="cardapio" class="grade"></div>
```

`style.css`:
```css
.grade { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
.cartao { border: 1px solid #ccc; border-radius: 8px; padding: 12px; }
.cartao h3 { margin: 0 0 6px; }
.esgotado { opacity: 0.4; }
```

`script.js`:
```js
const cardapio = [
  { nome: "Pão de queijo", preco: 4.5, disponivel: true },
  { nome: "Coxinha", preco: 6, disponivel: true },
  { nome: "Suco natural", preco: 5, disponivel: false },
  { nome: "Bolo de pote", preco: 7.5, disponivel: true }
];

function formatarPreco(valor) {
  return `R$ ${valor.toFixed(2).replace(".", ",")}`;
}

function criarCartao(item) {
  const classeExtra = item.disponivel ? "" : "esgotado";
  const status = item.disponivel ? "Disponível" : "Esgotado";
  return `
    <div class="cartao ${classeExtra}">
      <h3>${item.nome}</h3>
      <p>${formatarPreco(item.preco)}</p>
      <small>${status}</small>
    </div>`;
}

const container = document.querySelector("#cardapio");
container.innerHTML = cardapio.map(criarCartao).join("");
```

A última linha é a mais importante da seção: **`map`** transforma cada objeto num pedaço de HTML (string), **`join("")`** junta todos os pedaços, e o resultado entra de uma vez na página. Dado → HTML. Esse é o padrão que você vai repetir até o Módulo 10.

### 🎬 Nos bastidores — JSON é "objeto em forma de texto"

Quando um site busca dados de um servidor, eles chegam num formato chamado **JSON** (*JavaScript Object Notation*), que é praticamente a mesma escrita de arrays e objetos que você acabou de aprender, só que como texto:

```json
[{ "nome": "Pão de queijo", "preco": 4.5, "disponivel": true }]
```

Diferenças: no JSON as chaves **sempre** vão entre aspas duplas, e não existem funções. Você vai usar JSON no Módulo 9 (`localStorage`) e no bônus (`fetch`).

### 🐞 Ache o bug #1

```js
const turma = ["Ana", "Bruno", "Carla"];
console.log(`Último aluno: ${turma[turma.length]}`);
```

<details><summary>Resposta</summary>

Sai `Último aluno: undefined`. Com 3 itens, os índices são 0, 1 e 2. `turma.length` vale 3, que não existe. O correto é `turma[turma.length - 1]`.

</details>

### 🐞 Ache o bug #2

```js
const produtos = [
  { nome: "Caneta", preco: 3 },
  { nome: "Caderno", preco: 20 }
];

const baratos = produtos.filter(p => p.preco < 10);
console.log(baratos.nome);
```

<details><summary>Resposta</summary>

Sai `undefined`. `filter` **sempre** devolve um **array**, mesmo que tenha só um item. O correto é `baratos[0].nome` — ou, se você quer só o primeiro, usar `find` no lugar de `filter`.

</details>

### 🐞 Ache o bug #3

```js
const aluno = { nome: "Léo", nota: 7 };
const campo = "nota";
console.log(aluno.campo);
```

<details><summary>Resposta</summary>

Sai `undefined`. `aluno.campo` procura uma chave chamada literalmente `"campo"`. Para usar o valor da variável, use colchetes: `aluno[campo]`.

</details>

### 🔴 Lendo o console

```
Uncaught TypeError: Cannot read properties of undefined (reading 'nome')
    at script.js:8:24
```

Esse é o erro mais comum de todo o curso. Tradução: *"você tentou ler `.nome` de algo que é `undefined`"*. Exemplo que causa ele:

```js
const alunos = [{ nome: "Ana" }];
console.log(alunos[1].nome); // alunos[1] é undefined!
```

Quando vir esse erro, olhe para o que está **antes** do ponto (`alunos[1]`) e pergunte: *"por que isso está vazio?"*. Geralmente é índice errado, `find` que não achou nada, ou um nome de chave digitado errado.

### 🏋️ Academia de exercícios

1. Crie um array com 5 números e mostre o maior e o menor (sem `Math.max`, usando um laço).
2. Dado `["  ana ", "LEO", "bIa"]`, use `map` para deixar todos com a primeira letra maiúscula e sem espaços (dica: `trim`, `toLowerCase`, `charAt(0)`, `slice(1)`).
3. Crie um objeto `filme` com título, ano e nota, e um método `resumo()` que devolve uma frase com tudo.
4. Com um array de 6 produtos `{ nome, preco, categoria }`, calcule o preço médio de **uma** categoria.
5. Ordene o mesmo array por preço, do mais barato para o mais caro.

### 🧠 Confira sua memória

1. Qual o índice do primeiro item de um array? E do último?
2. Qual a diferença entre `push` e `unshift`? E entre `pop` e `shift`?
3. `filter` pode devolver `undefined`? E `find`?
4. Quando você precisa usar colchetes para acessar uma propriedade de um objeto?
5. Explique com suas palavras o que faz `lista.map(criarCartao).join("")`.

### Mini-projeto do módulo: "Boletim da turma"

Crie um array com pelo menos 8 alunos `{ nome, n1, n2, n3 }`. Usando funções do Módulo 4 e métodos deste módulo, gere na página: uma tabela com nome, média e situação de cada aluno; a média geral da turma; o nome do aluno com a maior média; e a quantidade de aprovados e reprovados.

---
## Módulo 6 — O DOM: JavaScript conversando com o HTML

> *"O HTML que você escreveu é a planta da casa. O DOM é a casa construída — e o JavaScript tem a chave."*

### 6.1 Do arquivo para a árvore

Quando o navegador abre seu `index.html`, ele não fica "olhando para o texto". Ele lê o arquivo e **constrói** na memória uma estrutura de objetos, um para cada tag. Essa estrutura é o **DOM** (*Document Object Model*, ou Modelo de Objetos do Documento).

```html
<body>
  <header>
    <h1>Minha loja</h1>
  </header>
  <main>
    <p class="aviso">Frete grátis hoje!</p>
    <ul id="produtos">
      <li>Caderno</li>
      <li>Caneta</li>
    </ul>
  </main>
</body>
```

vira uma árvore assim:

```
document
└── html
    └── body
        ├── header
        │   └── h1  "Minha loja"
        └── main
            ├── p.aviso  "Frete grátis hoje!"
            └── ul#produtos
                ├── li  "Caderno"
                └── li  "Caneta"
```

Vocabulário de família (que você já viu no curso de HTML): `main` é **pai** de `p` e `ul`; os dois `li` são **filhos** de `ul` e **irmãos** entre si.

A grande sacada: se você alterar o DOM, **a página muda na hora**. O arquivo `index.html` continua igual no seu computador, mas o que o usuário vê é o DOM.

### 🎬 Nos bastidores — veja o DOM com seus próprios olhos

Abra qualquer página, aperte F12 e vá na aba **Elements** (ou **Inspetor**). Aquilo **não** é o seu arquivo HTML: é o DOM ao vivo. Teste: dê dois cliques num texto ali e mude. A página muda e o arquivo, não. Agora vá no **Console** e digite `document.body.style.background = "pink"`. Você acabou de editar o DOM com JavaScript. Dica de ouro: no Elements, clique num elemento e digite `$0` no Console — `$0` é o elemento selecionado.

### 6.2 Selecionando elementos

Antes de mexer num elemento, você precisa **pegar** ele. A boa notícia: você usa os **mesmos seletores do CSS**.

```js
document.querySelector("h1");              // pela tag
document.querySelector("#produtos");       // pelo id
document.querySelector(".aviso");          // pela classe
document.querySelector("ul#produtos li");  // seletor composto
document.querySelector("li:last-child");   // pseudo-classe
document.querySelector('[type="email"]');  // atributo
```

| Método | Devolve | Se não achar |
|---|---|---|
| `querySelector(sel)` | o **primeiro** elemento | `null` |
| `querySelectorAll(sel)` | **todos** (uma `NodeList`) | lista vazia |

```js
const itens = document.querySelectorAll("#produtos li");
console.log(itens.length); // 2

itens.forEach(item => console.log(item.textContent));
```

### 🗣️ Não existe pergunta boba

**"E o `getElementById` que vejo em tutoriais?"**
`document.getElementById("produtos")` (sem `#`!) faz o mesmo que `querySelector("#produtos")`. É mais antigo e continua funcionando. Nesta apostila usamos `querySelector` para tudo porque você só precisa aprender **uma** forma, e ela usa a sintaxe de CSS que você já conhece.

**"Por que guardar o elemento numa `const`?"**
Para não procurar ele na página toda vez. `const titulo = document.querySelector("h1")` busca **uma** vez e deixa o elemento guardado, pronto para uso.

### 🔴 Lendo o console

```
Uncaught TypeError: Cannot set properties of null (setting 'textContent')
```

Tradução: *"você tentou mudar `.textContent` de algo que é `null`"*. Ou seja, o `querySelector` **não achou** o elemento. Os três suspeitos de sempre:

1. **Seletor errado**: esqueceu o `#` ou o `.`, ou digitou o nome diferente do HTML.
2. **Script rodando cedo demais**: falta `defer` no `<script>` do `<head>`.
3. **O elemento ainda não existe**: ele só vai ser criado depois, por outro código.

### 6.3 Lendo e mudando conteúdo

```html
<p id="msg">Olá, <strong>mundo</strong>!</p>
```

```js
const msg = document.querySelector("#msg");

console.log(msg.textContent); // "Olá, mundo!"           (só o texto)
console.log(msg.innerHTML);   // "Olá, <strong>mundo</strong>!" (com as tags)

msg.textContent = "Texto <em>novo</em>"; // aparece literalmente: Texto <em>novo</em>
msg.innerHTML   = "Texto <em>novo</em>"; // aparece: Texto *novo* (em itálico)
```

**Regra de segurança**: use `textContent` para qualquer coisa que veio do **usuário**. Use `innerHTML` só para HTML que **você** montou no código.

Por quê? Imagine um campo de comentário em que alguém digita:

```html
<img src="x" onerror="alert('Hackeado!')">
```

Se você mostrar isso com `innerHTML`, o navegador **executa** o código. Com `textContent`, ele só mostra o texto, inofensivo. Esse tipo de ataque se chama **XSS** e está entre os mais comuns da web.

#### Campos de formulário usam `.value`

```js
const campo = document.querySelector("#nome");
console.log(campo.value);   // o que está digitado
campo.value = "";           // limpa o campo
```

### 6.4 Atributos

```html
<img id="foto" src="gato.jpg" alt="Um gato">
<a id="link" href="https://developer.mozilla.org">MDN</a>
```

```js
const foto = document.querySelector("#foto");

foto.src = "cachorro.jpg";              // jeito direto (propriedade)
foto.alt = "Um cachorro";

const link = document.querySelector("#link");
link.setAttribute("target", "_blank");  // jeito genérico
console.log(link.getAttribute("href")); // "https://developer.mozilla.org"
link.removeAttribute("target");
```

Os atributos mais comuns (`src`, `href`, `alt`, `id`, `value`, `disabled`, `checked`) podem ser usados direto como propriedade. Para qualquer outro, use `getAttribute`/`setAttribute`.

#### Atributos `data-*`: guardando informação no HTML

```html
<button class="produto" data-id="42" data-preco="19.90">Comprar</button>
```

```js
const btn = document.querySelector(".produto");
console.log(btn.dataset.id);    // "42"
console.log(btn.dataset.preco); // "19.90"  ← sempre string!
```

Você vai usar muito `data-*` no Módulo 7 para saber **qual** item foi clicado.

### 6.5 Estilo: `classList` em vez de `style`

Dá para mudar o CSS direto:

```js
const caixa = document.querySelector("#caixa");
caixa.style.backgroundColor = "yellow"; // note: camelCase, não background-color
caixa.style.padding = "20px";
```

Funciona, mas espalha estilo no meio do JavaScript. O jeito profissional é: **o CSS define a aparência; o JavaScript só liga e desliga classes**.

```css
.destaque { background: #fff3a0; border-left: 4px solid orange; }
.escondido { display: none; }
.erro { color: crimson; }
```

```js
caixa.classList.add("destaque");        // coloca
caixa.classList.remove("destaque");     // tira
caixa.classList.toggle("escondido");    // se tem, tira; se não tem, coloca
caixa.classList.contains("erro");       // true ou false
caixa.classList.replace("erro", "ok");  // troca uma pela outra
```

Analogia: as classes CSS são os **figurinos** guardados no camarim. O JavaScript não costura roupa nova, ele só **troca o figurino** do ator na hora certa.

**Quando o `style` direto é aceitável?** Quando o valor é calculado na hora e não dá para prever no CSS: a largura de uma barra de progresso (`barra.style.width = porcentagem + "%"`), a posição de algo que segue o mouse, uma cor escolhida pelo usuário.

### ✏️ Aponte seu lápis

```html
<p id="p1" class="a b">Texto</p>
```

```js
const p = document.querySelector("#p1");
p.classList.add("c");
p.classList.remove("a");
p.classList.toggle("b");
p.classList.toggle("d");
console.log(p.className);
```

<details><summary>Resposta</summary>

`"c d"`. Começa com `a b` → add `c` → `a b c` → remove `a` → `b c` → toggle `b` (tinha, tira) → `c` → toggle `d` (não tinha, põe) → `c d`.

</details>

### 6.6 Criando, inserindo e removendo elementos

Três passos: **criar**, **configurar**, **encaixar**.

```js
const lista = document.querySelector("#produtos");

// 1. criar (ainda está "no ar", fora da página)
const novo = document.createElement("li");

// 2. configurar
novo.textContent = "Mochila";
novo.classList.add("novidade");

// 3. encaixar
lista.append(novo);     // no fim da lista
// lista.prepend(novo); // no começo da lista
```

E para tirar da página:

```js
novo.remove();
```

#### `innerHTML` ou `createElement`?

| | `innerHTML` + template string | `createElement` + `append` |
|---|---|---|
| Rapidez de escrever | ✅ bem rápido | mais linhas |
| Segurança com texto do usuário | ⚠️ risco de XSS | ✅ seguro com `textContent` |
| Colocar evento no elemento criado | precisa selecionar depois | ✅ você já tem o elemento na mão |
| Bom para | listas fixas, dados seus | dados do usuário, itens com botões |

Você vai usar os dois. A regra prática: **se o texto veio do usuário, ou se o item precisa de um botão próprio, use `createElement`**.

#### Exemplo completo: lista gerada a partir de array, com `createElement`

```js
const tarefas = ["Estudar DOM", "Fazer exercícios", "Revisar Módulo 5"];
const ul = document.querySelector("#tarefas");

tarefas.forEach((texto, i) => {
  const li = document.createElement("li");
  li.textContent = `${i + 1}. ${texto}`;
  if (i === 0) li.classList.add("destaque");
  ul.append(li);
});
```

#### Limpando um container antes de redesenhar

```js
ul.innerHTML = ""; // apaga todos os filhos
```

Você vai usar essa linha **muito**: limpar e redesenhar a lista inteira a partir dos dados é o jeito mais simples de manter a tela sincronizada.

### 6.7 Navegando pela árvore

Às vezes você já tem um elemento e precisa chegar no pai, nos filhos ou num vizinho:

```js
const item = document.querySelector("li");

item.parentElement;            // o <ul>
item.nextElementSibling;       // o próximo <li>
item.previousElementSibling;   // o <li> anterior (ou null)
item.closest("main");          // sobe até achar um <main>
lista.children;                // todos os filhos
lista.firstElementChild;       // o primeiro filho
```

`closest` é o mais útil de todos: a partir de um elemento, ele **sobe** na árvore até achar o primeiro ancestral que bate com o seletor. Guarde ele para o Módulo 7.

### 6.8 Projeto guiado: painel de notificações

`index.html`:
```html
<h1>Avisos da coordenação</h1>
<p>Você tem <span id="contador">0</span> avisos.</p>
<ul id="avisos"></ul>
```

`style.css`:
```css
#avisos { list-style: none; padding: 0; display: grid; gap: 8px; }
.aviso { padding: 10px 14px; border-radius: 6px; background: #eef; }
.aviso.urgente { background: #fdd; font-weight: bold; }
.aviso small { display: block; opacity: 0.7; }
```

`script.js`:
```js
const avisos = [
  { titulo: "Prova de JS na sexta", data: "03/10", urgente: true },
  { titulo: "Feira de profissões", data: "10/10", urgente: false },
  { titulo: "Entrega do projeto integrador", data: "28/11", urgente: true }
];

const ul = document.querySelector("#avisos");
const contador = document.querySelector("#contador");

function criarAviso(aviso) {
  const li = document.createElement("li");
  li.classList.add("aviso");
  if (aviso.urgente) li.classList.add("urgente");

  const titulo = document.createElement("span");
  titulo.textContent = aviso.titulo;

  const data = document.createElement("small");
  data.textContent = `Data: ${aviso.data}`;

  li.append(titulo, data);
  return li;
}

function renderizar() {
  ul.innerHTML = "";
  avisos.forEach(a => ul.append(criarAviso(a)));
  contador.textContent = avisos.length;
}

renderizar();
```

Repare na estrutura: **dados** (o array) → função que transforma **um** dado em **um** elemento (`criarAviso`) → função que **desenha tudo** (`renderizar`). Esse trio volta em todos os módulos daqui para frente.

### 🐞 Ache o bug #1

```html
<p class="nota">7</p>
<p class="nota">4</p>
<p class="nota">9</p>
```

```js
const notas = document.querySelector(".nota");
notas.forEach(n => {
  if (Number(n.textContent) < 6) n.classList.add("erro");
});
```

<details><summary>Resposta</summary>

Erro: `notas.forEach is not a function`. `querySelector` devolve **um** elemento, e elemento não tem `forEach`. O correto é `querySelectorAll(".nota")`.

</details>

### 🐞 Ache o bug #2

```js
const li = document.createElement("li");
li.textContent = "Novo item";
```

O código roda sem erro, mas o item não aparece na página. Por quê?

<details><summary>Resposta</summary>

O elemento foi **criado** mas nunca **encaixado** na página. Falta o terceiro passo: `document.querySelector("ul").append(li);`.

</details>

### 🐞 Ache o bug #3

```js
const titulo = document.querySelector("titulo");
titulo.textContent = "Bem-vindo";
```

```html
<h1 id="titulo">...</h1>
```

<details><summary>Resposta</summary>

O seletor `"titulo"` procura uma **tag** `<titulo>`, que não existe, e devolve `null`. Faltou o `#`: `querySelector("#titulo")`.

</details>

### 🏋️ Academia de exercícios

1. Numa página com 5 `<li>`, pinte de cinza os itens de posição par (use `querySelectorAll` + `forEach` com índice).
2. Troque o `src` de uma imagem e atualize o `alt` junto.
3. Gere uma tabela `<table>` a partir de um array de objetos usando `createElement("tr")` e `createElement("td")`.
4. Crie uma barra de progresso: uma `<div>` cuja largura (`style.width`) vem de uma variável `porcentagem`.
5. Com `dataset`, leia o preço de 4 botões `data-preco` e mostre a soma num `<p>`.

### 🧠 Confira sua memória

1. Qual a diferença entre o arquivo HTML e o DOM?
2. O que `querySelector` devolve quando não encontra nada? E `querySelectorAll`?
3. Por que `textContent` é mais seguro que `innerHTML`?
4. Por que é melhor usar `classList` do que `style` na maioria dos casos?
5. Quais são os três passos para colocar um elemento novo na página?

### Mini-projeto do módulo: "Vitrine da turma"

Monte uma vitrine com um array de 6 "projetos da turma" `{ titulo, autor, tecnologia, destaque }`. Renderize cada um como um cartão criado com `createElement`. Cartões com `destaque: true` ganham uma classe CSS especial. Mostre no topo da página quantos projetos usam cada tecnologia.

---
## Módulo 7 — Eventos: a página que reage

> *"Até agora o seu código falava sozinho. A partir de agora, ele escuta."*

### 7.1 Programar é esperar

Pense num porteiro de prédio. Ele não fica correndo pelos andares o tempo todo. Ele **espera**. Quando o interfone toca, ele **reage**: atende, confere quem é, abre o portão.

Uma página interativa funciona igual. Você diz ao navegador: *"quando **este** elemento sofrer **este** acontecimento, rode **esta** função"*. E o navegador fica de porteiro.

Esse acontecimento se chama **evento**. A função que reage se chama **ouvinte** (*listener*) ou **manipulador** (*handler*).

### 7.2 `addEventListener`

```html
<button id="btn">Clique em mim</button>
<p id="saida">Ninguém clicou ainda.</p>
```

```js
const btn = document.querySelector("#btn");
const saida = document.querySelector("#saida");

btn.addEventListener("click", () => {
  saida.textContent = "Clicou! 🎉";
});
```

A frase completa é: **elemento**`.addEventListener(`**"tipo de evento"**`, `**função**`)`.

#### O erro número 1 de todo mundo

```js
function avisar() {
  saida.textContent = "Clicou!";
}

btn.addEventListener("click", avisar);   // ✅ entrega a RECEITA
btn.addEventListener("click", avisar()); // ❌ executa AGORA e entrega o resultado (undefined)
```

Lembra do *"funções são valores"*? Sem parênteses, você **entrega a função** para o navegador chamar depois. Com parênteses, você **chama a função na hora** — e o que vai para o navegador é o que ela devolveu.

### 7.3 O cardápio de eventos

| Evento | Quando dispara | Uso típico |
|---|---|---|
| `click` | clique (ou toque) | botões, cartões |
| `dblclick` | duplo clique | editar um item |
| `mouseenter` / `mouseleave` | mouse entra / sai | dicas, destaques |
| `input` | **a cada** alteração num campo | busca ao vivo, contador de caracteres |
| `change` | ao **confirmar** a alteração (sair do campo, escolher no select) | `<select>`, `checkbox` |
| `keydown` | tecla pressionada | atalhos, jogos |
| `submit` | formulário enviado | cadastros (Módulo 8) |
| `focus` / `blur` | campo ganha / perde o foco | validar ao sair do campo |
| `DOMContentLoaded` | HTML terminou de carregar | (com `defer` você raramente precisa) |

Exemplos rápidos:

```js
// Busca ao vivo
const busca = document.querySelector("#busca");
busca.addEventListener("input", () => {
  console.log(`Procurando: ${busca.value}`);
});

// Select
const tema = document.querySelector("#tema");
tema.addEventListener("change", () => {
  document.body.className = tema.value; // "claro" ou "escuro"
});

// Hover
const cartao = document.querySelector(".cartao");
cartao.addEventListener("mouseenter", () => cartao.classList.add("ativo"));
cartao.addEventListener("mouseleave", () => cartao.classList.remove("ativo"));
```

### 7.4 O objeto `event`: o relatório do que aconteceu

Toda função ouvinte recebe, de presente, um parâmetro com **detalhes** do evento. Pode chamar de `event`, `evento` ou `e`.

```js
document.addEventListener("keydown", (e) => {
  console.log(`Tecla: ${e.key}`);       // "a", "Enter", "ArrowUp"...
  console.log(`Ctrl apertado? ${e.ctrlKey}`);
});

document.querySelector("#area").addEventListener("click", (e) => {
  console.log(`Clicou em x=${e.clientX}, y=${e.clientY}`);
  console.log(e.target); // o elemento exato que recebeu o clique
});
```

As propriedades mais usadas:

| Propriedade | O que traz |
|---|---|
| `e.target` | o elemento que **originou** o evento |
| `e.currentTarget` | o elemento que tem o **ouvinte** |
| `e.key` | a tecla (em eventos de teclado) |
| `e.clientX`, `e.clientY` | posição do mouse |
| `e.preventDefault()` | cancela o comportamento padrão do navegador |

### 7.5 `preventDefault`: "navegador, deixa comigo"

Alguns elementos já fazem algo sozinhos: um link navega, um formulário recarrega a página, a barra de espaço rola a tela. `preventDefault()` cancela esse comportamento.

```js
const link = document.querySelector("#linkSecreto");
link.addEventListener("click", (e) => {
  e.preventDefault();
  alert("Esse link está em manutenção!");
});

document.querySelector("form").addEventListener("submit", (e) => {
  e.preventDefault(); // sem isso, a página recarrega e tudo some
  console.log("Formulário tratado pelo JavaScript!");
});
```

### 7.6 Estado: a memória da interação

Um contador precisa **lembrar** quantas vezes foi clicado. Essa memória é uma variável **fora** da função ouvinte (lembra do Ache o bug #3 do Módulo 4?):

```html
<button id="menos">−</button>
<span id="valor">0</span>
<button id="mais">+</button>
```

```js
let quantidade = 0; // o ESTADO

const valor = document.querySelector("#valor");

function atualizarTela() {
  valor.textContent = quantidade;
  valor.classList.toggle("negativo", quantidade < 0);
}

document.querySelector("#mais").addEventListener("click", () => {
  quantidade++;
  atualizarTela();
});

document.querySelector("#menos").addEventListener("click", () => {
  quantidade--;
  atualizarTela();
});
```

Repare no padrão: **o evento muda o estado → a função de tela desenha o estado**. O evento nunca mexe direto na tela. Isso parece burocrático num contador, mas é o que mantém aplicações grandes sem bugs.

> Detalhe: `classList.toggle("negativo", condicao)` com **dois** argumentos **liga** a classe se a condição for verdadeira e **desliga** se for falsa. Muito útil.

### 🗣️ Não existe pergunta boba

**"E o `onclick` que vejo no HTML, tipo `<button onclick="fazer()">`?"**
Funciona, mas mistura JavaScript dentro do HTML (lembra por que separamos os arquivos?) e só permite **um** ouvinte por evento. `addEventListener` mantém tudo no `.js` e permite vários ouvintes. Prefira sempre ele.

**"Dá para parar de ouvir um evento?"**
Dá, com `removeEventListener("click", nomeDaFuncao)` — mas só funciona se a função tiver **nome** (não dá para remover uma arrow function anônima). Outra opção simples: `addEventListener("click", f, { once: true })` faz o ouvinte rodar **uma vez só**.

### 7.7 Um ouvinte para cada item

Para reagir a vários elementos parecidos, use `querySelectorAll` + `forEach`:

```html
<button class="cor" data-cor="tomato">Vermelho</button>
<button class="cor" data-cor="seagreen">Verde</button>
<button class="cor" data-cor="royalblue">Azul</button>
<div id="amostra">Amostra</div>
```

```js
const amostra = document.querySelector("#amostra");

document.querySelectorAll(".cor").forEach(botao => {
  botao.addEventListener("click", () => {
    amostra.style.backgroundColor = botao.dataset.cor;
  });
});
```

### 7.8 Delegação de eventos: um ouvinte para todos

O método acima tem um problema: só funciona para os botões que **já existem**. Se você criar um botão novo depois (com `createElement`), ele não tem ouvinte.

A solução se chama **delegação**: em vez de colocar um ouvinte em cada filho, coloque **um** no pai. Funciona porque os eventos **sobem** pela árvore do DOM — isso se chama **propagação** (*bubbling*). Um clique no `<li>` também é um clique no `<ul>`, no `<main>`, no `<body>`...

Analogia: em vez de colocar um porteiro em cada apartamento, você coloca **um** porteiro na entrada do prédio, que pergunta *"para qual apartamento?"*.

```html
<ul id="lista">
  <li>Arroz <button class="remover">×</button></li>
  <li>Feijão <button class="remover">×</button></li>
</ul>
<button id="adicionar">Adicionar item</button>
```

```js
const lista = document.querySelector("#lista");

lista.addEventListener("click", (e) => {
  if (e.target.classList.contains("remover")) {
    e.target.closest("li").remove();
  }
});

document.querySelector("#adicionar").addEventListener("click", () => {
  const li = document.createElement("li");
  li.innerHTML = `Item novo <button class="remover">×</button>`;
  lista.append(li);
});
```

Teste: adicione itens novos e clique no `×` deles. Funciona! O ouvinte está no `<ul>`, que existe desde o começo. `e.target` diz **onde** foi o clique, e `closest("li")` sobe até o item inteiro.

### ✏️ Aponte seu lápis

```html
<div id="caixa"><button id="botao">OK</button></div>
```

```js
document.querySelector("#caixa").addEventListener("click", () => console.log("caixa"));
document.querySelector("#botao").addEventListener("click", () => console.log("botão"));
```

Clicando no botão, o que aparece no console e em que ordem?

<details><summary>Resposta</summary>

`botão` e depois `caixa`. O evento acontece no botão e depois **sobe** (propagação) para a `div`. Se você quisesse impedir a subida, usaria `e.stopPropagation()` no ouvinte do botão — mas use isso com moderação.

</details>

### 7.9 Teclado

```js
const personagem = document.querySelector("#personagem");
let x = 0;

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight") x += 10;
  if (e.key === "ArrowLeft") x -= 10;
  personagem.style.transform = `translateX(${x}px)`;
});
```

E o clássico "Enter para enviar" num campo de chat:

```js
const campo = document.querySelector("#mensagem");
campo.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && campo.value.trim() !== "") {
    console.log(`Enviado: ${campo.value}`);
    campo.value = "";
  }
});
```

### 7.10 Projeto guiado: galeria com miniaturas

Retomando a galeria do Módulo 6, agora clicável:

`index.html`:
```html
<img id="principal" src="https://picsum.photos/id/10/600/400" alt="Foto principal">
<div id="miniaturas"></div>
```

`style.css`:
```css
#principal { width: 100%; max-width: 600px; border-radius: 8px; }
#miniaturas { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
.mini { width: 90px; cursor: pointer; opacity: 0.5; border-radius: 4px; transition: opacity .2s; }
.mini.ativa, .mini:hover { opacity: 1; }
```

`script.js`:
```js
const fotos = [10, 20, 30, 40].map(id => `https://picsum.photos/id/${id}/600/400`);
const principal = document.querySelector("#principal");
const container = document.querySelector("#miniaturas");

fotos.forEach((url, i) => {
  const img = document.createElement("img");
  img.src = url;
  img.alt = `Miniatura ${i + 1}`;
  img.classList.add("mini");
  if (i === 0) img.classList.add("ativa");
  container.append(img);
});

container.addEventListener("click", (e) => {
  if (!e.target.classList.contains("mini")) return;

  principal.src = e.target.src;
  container.querySelector(".ativa").classList.remove("ativa");
  e.target.classList.add("ativa");
});
```

Aqui aparece tudo junto: array → `createElement`, delegação no container, `return` antecipado para ignorar cliques fora das miniaturas, e `classList` para marcar a ativa.

### 🐞 Ache o bug #1

```js
let pontos = 0;
document.querySelector("#btn").addEventListener("click", () => {
  pontos + 1;
  document.querySelector("#placar").textContent = pontos;
});
```

<details><summary>Resposta</summary>

O placar fica sempre `0`. `pontos + 1` calcula, mas não **guarda**. O correto é `pontos = pontos + 1;` ou `pontos++;`.

</details>

### 🐞 Ache o bug #2

```js
const botoes = document.querySelectorAll(".curtir");
botoes.addEventListener("click", () => console.log("curtiu"));
```

<details><summary>Resposta</summary>

Erro: `botoes.addEventListener is not a function`. Uma **lista** de elementos não tem `addEventListener`; cada elemento tem. Use `botoes.forEach(b => b.addEventListener(...))` ou delegação.

</details>

### 🐞 Ache o bug #3

```html
<form id="busca">
  <input id="termo">
  <button>Buscar</button>
</form>
```

```js
document.querySelector("#busca").addEventListener("submit", () => {
  document.querySelector("#resultado").textContent = "Buscando...";
});
```

A mensagem pisca e some. Por quê?

<details><summary>Resposta</summary>

Faltou receber o evento e chamar `e.preventDefault()`. Sem isso, o formulário recarrega a página e apaga a mensagem.

</details>

### 🏋️ Academia de exercícios

1. Um botão "modo escuro" que alterna a classe `escuro` no `<body>`.
2. Um campo de texto com contador "X/140 caracteres" que fica vermelho acima de 140.
3. Um quadrado que muda de cor aleatória a cada clique (`Math.random`).
4. Uma lista de compras com delegação: clicar no item risca, clicar no `×` remove.
5. Um "jogo do botão fugitivo": quando o mouse entra no botão, ele pula para uma posição aleatória.

### 🧠 Confira sua memória

1. Qual a diferença entre `addEventListener("click", f)` e `addEventListener("click", f())`?
2. Qual a diferença entre os eventos `input` e `change`?
3. Para que serve `e.target`? E `e.preventDefault()`?
4. O que é propagação de eventos?
5. Por que a delegação funciona para elementos criados depois?

### Mini-projeto do módulo: "Quiz relâmpago"

Um array de 5 perguntas `{ pergunta, opcoes, correta }`. Mostre uma pergunta por vez com os botões das opções (crie os botões com `createElement`). Ao clicar, pinte de verde ou vermelho, some o ponto e, depois de 1 segundo (`setTimeout`), passe para a próxima. No fim, mostre a pontuação e um botão "Jogar de novo".

---
## Módulo 8 — Formulários e validação

> *"Nunca confie no que o usuário digita. Não por maldade dele — por pressa, por erro de digitação, por curiosidade. Valide sempre."*

### 8.1 O formulário é a porta de entrada dos dados

Tudo o que você aprendeu até aqui usava dados **fixos no código**. No mundo real, os dados vêm do **usuário**: cadastro, login, busca, comentário, pedido. E o usuário vai digitar de tudo: campo vazio, e-mail sem `@`, idade `"dezesseis"`, nome com 3 espaços no começo...

Validar é **conferir antes de aceitar**. E dar um retorno claro de **o que** está errado e **como** corrigir.

### 8.2 Estrutura que vamos usar no módulo inteiro

`index.html`:
```html
<form id="cadastro" novalidate>
  <div class="campo">
    <label for="nome">Nome completo</label>
    <input id="nome" name="nome" type="text">
    <small class="msg"></small>
  </div>

  <div class="campo">
    <label for="email">E-mail</label>
    <input id="email" name="email" type="email">
    <small class="msg"></small>
  </div>

  <div class="campo">
    <label for="idade">Idade</label>
    <input id="idade" name="idade" type="number">
    <small class="msg"></small>
  </div>

  <div class="campo">
    <label for="curso">Curso</label>
    <select id="curso" name="curso">
      <option value="">Selecione...</option>
      <option value="info">Informática</option>
      <option value="adm">Administração</option>
      <option value="enf">Enfermagem</option>
    </select>
    <small class="msg"></small>
  </div>

  <label><input id="termos" type="checkbox"> Li e aceito o regulamento</label>

  <button type="submit">Cadastrar</button>
  <p id="resultado"></p>
</form>
```

`style.css`:
```css
.campo { display: grid; gap: 4px; margin-bottom: 12px; }
.campo input, .campo select { padding: 8px; border: 2px solid #bbb; border-radius: 6px; }
.campo.invalido input, .campo.invalido select { border-color: crimson; }
.campo.valido input, .campo.valido select { border-color: seagreen; }
.msg { color: crimson; min-height: 1em; }
#resultado.sucesso { color: seagreen; font-weight: bold; }
```

> O atributo `novalidate` no `<form>` desliga os balões de validação automáticos do navegador, para que a **nossa** validação em JS apareça. Na seção 8.6 a gente fala sobre quando manter a validação nativa.

### 8.3 Lendo os valores de cada tipo de campo

```js
const form = document.querySelector("#cadastro");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const nome   = document.querySelector("#nome").value.trim();
  const email  = document.querySelector("#email").value.trim();
  const idade  = Number(document.querySelector("#idade").value);
  const curso  = document.querySelector("#curso").value;
  const termos = document.querySelector("#termos").checked;

  console.log({ nome, email, idade, curso, termos });
});
```

| Campo | Como ler | Detalhe |
|---|---|---|
| `input` texto, e-mail, senha | `.value` | sempre **string** |
| `input type="number"` | `Number(campo.value)` | `.value` é string! Vazio vira `0` |
| `textarea` | `.value` | string, pode ter quebras de linha |
| `select` | `.value` | o `value` da `<option>` escolhida |
| `checkbox` | `.checked` | `true` / `false` |
| `radio` | `document.querySelector('input[name="x"]:checked')?.value` | `undefined` se nenhum marcado |

#### O `.trim()` é seu melhor amigo

```js
"   Ana   ".trim(); // "Ana"
"     ".trim();     // ""  ← um campo cheio de espaços está, na prática, vazio
```

Use `.trim()` em **todo** texto antes de validar.

### 🎬 Nos bastidores — `FormData`, o atalho

Para formulários grandes, existe um atalho que lê todos os campos de uma vez pelo atributo `name`:

```js
const dados = Object.fromEntries(new FormData(form));
console.log(dados); // { nome: "...", email: "...", idade: "...", curso: "..." }
```

Atenção: tudo vem como string, e checkboxes desmarcados não aparecem. Nesta apostila lemos campo a campo, que é mais claro para aprender.

### 8.4 Regras de validação comuns

Cada regra é uma pergunta de sim ou não. Por isso, funções que devolvem `true`/`false` (Módulo 4) caem como uma luva:

```js
const estaVazio     = (texto) => texto.trim() === "";
const temMinimo     = (texto, n) => texto.trim().length >= n;
const emailValido   = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
const somenteLetras = (texto) => /^[A-Za-zÀ-ÿ\s]+$/.test(texto);
const entre         = (n, min, max) => n >= min && n <= max;
const temNumero     = (texto) => /\d/.test(texto);
```

### 🗣️ Não existe pergunta boba

**"O que é esse `/^[^\s@]+@.../`?"**
É uma **expressão regular** (*regex*): uma "mini linguagem" para descrever padrões de texto. Essa aí diz, mais ou menos: *"um monte de caracteres que não são espaço nem @, depois um @, depois mais caracteres, um ponto e mais caracteres"*. Você **não precisa** decorar regex agora; use as prontas desta página. Se não quiser usar regex, uma versão simplificada é `email.includes("@") && email.includes(".")`.

**"Validar no JavaScript deixa meu site seguro?"**
**Não!** Qualquer pessoa pode abrir o DevTools e desligar o seu JavaScript. A validação no navegador serve para a **experiência do usuário** (avisar rápido). Quando existe um servidor, ele **sempre** precisa validar de novo. Guarde isso para os próximos cursos.

### 8.5 Mostrando o erro no lugar certo

Mensagem de erro no `console.log` não serve para o usuário. Ela tem que aparecer **ao lado do campo**, com a borda vermelha:

```js
function marcarErro(campo, mensagem) {
  const div = campo.closest(".campo");
  div.classList.add("invalido");
  div.classList.remove("valido");
  div.querySelector(".msg").textContent = mensagem;
}

function marcarOk(campo) {
  const div = campo.closest(".campo");
  div.classList.remove("invalido");
  div.classList.add("valido");
  div.querySelector(".msg").textContent = "";
}
```

Repare no `closest(".campo")` do Módulo 6: a partir do `input`, sobe até a `div` que agrupa label, campo e mensagem.

#### Juntando tudo

```js
const form = document.querySelector("#cadastro");
const resultado = document.querySelector("#resultado");

function validarNome() {
  const campo = document.querySelector("#nome");
  const valor = campo.value.trim();
  if (estaVazio(valor)) return marcarErro(campo, "Informe seu nome."), false;
  if (!temMinimo(valor, 3)) return marcarErro(campo, "O nome precisa de pelo menos 3 letras."), false;
  marcarOk(campo);
  return true;
}
```

Hmm, essa vírgula aí ficou "esperta demais" e difícil de ler. **Código claro vale mais que código curto.** Vamos reescrever do jeito que qualquer colega entende:

```js
function validarNome() {
  const campo = document.querySelector("#nome");
  const valor = campo.value.trim();

  if (estaVazio(valor)) {
    marcarErro(campo, "Informe seu nome.");
    return false;
  }
  if (!temMinimo(valor, 3)) {
    marcarErro(campo, "O nome precisa de pelo menos 3 letras.");
    return false;
  }
  marcarOk(campo);
  return true;
}

function validarEmail() {
  const campo = document.querySelector("#email");
  if (!emailValido(campo.value.trim())) {
    marcarErro(campo, "Digite um e-mail no formato nome@dominio.com.");
    return false;
  }
  marcarOk(campo);
  return true;
}

function validarIdade() {
  const campo = document.querySelector("#idade");
  const idade = Number(campo.value);
  if (campo.value === "" || !entre(idade, 14, 99)) {
    marcarErro(campo, "A idade deve estar entre 14 e 99 anos.");
    return false;
  }
  marcarOk(campo);
  return true;
}

function validarCurso() {
  const campo = document.querySelector("#curso");
  if (campo.value === "") {
    marcarErro(campo, "Escolha um curso.");
    return false;
  }
  marcarOk(campo);
  return true;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  resultado.textContent = "";
  resultado.className = "";

  const resultados = [validarNome(), validarEmail(), validarIdade(), validarCurso()];
  const termos = document.querySelector("#termos").checked;

  if (!termos) {
    resultado.textContent = "Você precisa aceitar o regulamento.";
    return;
  }

  if (resultados.includes(false)) return;

  const nome = document.querySelector("#nome").value.trim();
  resultado.textContent = `Cadastro realizado! Bem-vindo(a), ${nome}.`;
  resultado.classList.add("sucesso");
  form.reset();
  document.querySelectorAll(".campo").forEach(c => c.classList.remove("valido"));
});
```

Dois detalhes importantes:

- Guardamos **todos** os resultados num array **antes** de decidir. Se usássemos `if (!validarNome() || !validarEmail() ...)`, o `||` pararia no primeiro erro e o usuário só veria **uma** mensagem por vez. Assim ele vê todos os problemas de uma vez.
- `resultados.includes(false)` responde "algum deu falso?".

### 8.6 Validação ao vivo

Esperar o clique em "Cadastrar" para avisar é chato. Dá para validar quando o usuário **sai** do campo (`blur`) ou **enquanto digita** (`input`):

```js
document.querySelector("#nome").addEventListener("blur", validarNome);
document.querySelector("#email").addEventListener("blur", validarEmail);
document.querySelector("#idade").addEventListener("input", validarIdade);
```

Repare que passamos as funções **sem parênteses** (Módulo 7!).

#### E a validação nativa do HTML5?

Atributos como `required`, `minlength`, `min`, `max`, `type="email"` e `pattern` também validam, sem JavaScript nenhum:

```html
<input type="email" required>
<input type="number" min="14" max="99" required>
<input type="text" minlength="3" required>
```

| | HTML5 nativo | JavaScript |
|---|---|---|
| Esforço | quase zero | mais código |
| Mensagem | padrão do navegador | do jeito que você quiser |
| Regras complexas (senhas iguais, CPF) | ❌ | ✅ |
| Funciona com JS desligado | ✅ | ❌ |

Na prática profissional, os dois convivem. Nesta apostila usamos `novalidate` só para conseguir **ver** a nossa validação funcionando.

### 8.7 Exemplos para estudar

**Força da senha ao vivo**

```html
<input id="senha" type="password">
<div id="barra"></div>
<small id="nivel"></small>
```

```js
const senha = document.querySelector("#senha");
const barra = document.querySelector("#barra");
const nivel = document.querySelector("#nivel");

senha.addEventListener("input", () => {
  const s = senha.value;
  let pontos = 0;
  if (s.length >= 8) pontos++;
  if (/[A-Z]/.test(s)) pontos++;
  if (/\d/.test(s)) pontos++;
  if (/[^A-Za-z0-9]/.test(s)) pontos++;

  const nomes = ["Muito fraca", "Fraca", "Média", "Boa", "Forte"];
  const cores = ["#ccc", "crimson", "orange", "gold", "seagreen"];

  barra.style.width = `${pontos * 25}%`;
  barra.style.height = "6px";
  barra.style.background = cores[pontos];
  nivel.textContent = nomes[pontos];
});
```

Um uso honesto de `style` direto: a largura depende de um valor calculado.

**Confirmar senha**

```js
function senhasIguais() {
  const s1 = document.querySelector("#senha").value;
  const s2 = document.querySelector("#confirma").value;
  return s1 !== "" && s1 === s2;
}
```

**Máscara simples de telefone**

```js
const tel = document.querySelector("#telefone");
tel.addEventListener("input", () => {
  const n = tel.value.replace(/\D/g, "").slice(0, 11); // só dígitos, máx. 11
  if (n.length > 6) tel.value = `(${n.slice(0, 2)}) ${n.slice(2, 7)}-${n.slice(7)}`;
  else if (n.length > 2) tel.value = `(${n.slice(0, 2)}) ${n.slice(2)}`;
  else tel.value = n;
});
```

### 🔴 Lendo o console — o erro que não aparece

Este é traiçoeiro porque **não dá erro nenhum**:

```js
const idade = document.querySelector("#idade").value;
if (idade >= 18) { /* ... */ }
```

Funciona "quase sempre", porque o `>=` converte a string em número. Mas `idade + 1` vira `"171"` (Módulo 1). Regra: **converta com `Number()` logo na leitura**. E lembre que `Number("")` é `0`, não "vazio" — por isso a validação de idade da seção 8.5 confere `campo.value === ""` antes.

### 🐞 Ache o bug #1

```js
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const nome = document.querySelector("#nome").value;
  if (nome === "") {
    alert("Preencha o nome!");
  }
});
```

O usuário digita só espaços e o cadastro passa. Por quê?

<details><summary>Resposta</summary>

`"   " === ""` é `false`. Faltou `.trim()`: `document.querySelector("#nome").value.trim()`.

</details>

### 🐞 Ache o bug #2

```js
const aceitou = document.querySelector("#termos").value;
if (!aceitou) {
  console.log("Aceite os termos");
}
```

<details><summary>Resposta</summary>

O `.value` de um checkbox é sempre `"on"` (marcado ou não), então `!aceitou` é sempre `false`. Para saber se está marcado, use `.checked`.

</details>

### 🐞 Ache o bug #3

```js
if (!validarNome() || !validarEmail() || !validarIdade()) {
  return;
}
```

O formulário funciona, mas o usuário reclama: *"corrijo um erro e aparece outro, e mais outro..."*.

<details><summary>Resposta</summary>

O `||` para de avaliar no primeiro `true`. Se `!validarNome()` já for `true`, as outras funções nem rodam, e os outros campos não mostram erro. Solução da seção 8.5: chamar todas, guardar num array e depois conferir com `includes(false)`.

</details>

### 🏋️ Academia de exercícios

1. Formulário de login: usuário (mín. 4 caracteres) e senha (mín. 6), com mensagens embaixo de cada campo.
2. Contador de caracteres num `<textarea>` com limite de 200, desabilitando o botão quando passar.
3. Formulário com `radio` (turno: manhã/tarde/noite) e mensagem se nenhum for escolhido.
4. Calculadora de IMC com formulário, validando que peso e altura sejam números positivos.
5. Cadastro com "senha" e "confirmar senha" que avisa ao vivo se não coincidem.

### 🧠 Confira sua memória

1. Por que usar `.trim()` antes de validar texto?
2. Como saber se um checkbox está marcado?
3. Que tipo de dado `.value` devolve num `input type="number"`?
4. Por que a validação no navegador **não** garante segurança?
5. Por que é melhor mostrar todos os erros de uma vez?

### Mini-projeto do módulo: "Inscrição na gincana"

Formulário com: nome da equipe (mín. 4), e-mail do líder, número de integrantes (3 a 6), série (select), turno (radio) e aceite do regulamento. Validação no envio **e** ao sair de cada campo, mensagens específicas embaixo de cada campo, e, em caso de sucesso, um "comprovante" gerado na página com os dados da inscrição.

---
## Módulo 9 — Guardando dados: `localStorage`

> *"Uma página sem memória é como um caderno que se apaga sozinho toda vez que você fecha."*

### 9.1 O problema: o F5 apaga tudo

Pegue qualquer projeto dos módulos anteriores: adicione itens numa lista, marque tarefas, mude o tema para escuro. Agora aperte **F5**. Tudo volta ao começo.

Por quê? Porque variáveis vivem na **memória RAM da aba**. Ao recarregar, o navegador joga essa memória fora e roda o `script.js` do zero, com os valores iniciais de novo.

Para os dados **sobreviverem**, precisamos gravá-los em algum lugar que não seja apagado. O navegador oferece um: o **`localStorage`**.

### 9.2 A gaveta com etiquetas

Pense no `localStorage` como uma **gaveta de arquivo** que pertence ao seu site, guardada no computador do usuário. Cada pasta da gaveta tem uma **etiqueta** (chave) e um **papel** dentro (valor).

```js
localStorage.setItem("nome", "Ana");        // guarda
const nome = localStorage.getItem("nome");  // lê → "Ana"
localStorage.removeItem("nome");            // apaga uma pasta
localStorage.clear();                       // esvazia a gaveta inteira (cuidado!)
```

| Método | O que faz | Se a chave não existir |
|---|---|---|
| `setItem(chave, valor)` | grava (ou sobrescreve) | cria |
| `getItem(chave)` | lê | devolve `null` |
| `removeItem(chave)` | apaga essa chave | não faz nada |
| `clear()` | apaga **tudo** do site | não faz nada |

### 🎬 Nos bastidores — onde fica essa gaveta?

Abra o DevTools → aba **Application** (Chrome/Edge) ou **Armazenamento** (Firefox) → **Local Storage** → seu site. Lá está a tabela de chaves e valores. Você pode editar e apagar na mão, o que é ótimo para testar. Alguns fatos:

- Cada **site** (domínio) tem a sua gaveta. Um site não lê a gaveta do outro.
- Cabe em torno de **5 MB** por site: ótimo para preferências e listas, ruim para fotos e vídeos.
- Os dados ficam **só naquele navegador, naquele computador**. Abriu no celular? Gaveta diferente, vazia.
- Na aba anônima, a gaveta é apagada quando você fecha a janela.

### 9.3 A regra de ouro: só guarda texto

```js
localStorage.setItem("pontos", 10);
const pontos = localStorage.getItem("pontos");

console.log(pontos);          // "10"
console.log(typeof pontos);   // "string"
console.log(pontos + 5);      // "105"  😱
console.log(Number(pontos) + 5); // 15 ✅
```

E com arrays e objetos é pior:

```js
const lista = ["pão", "leite"];
localStorage.setItem("compras", lista);
console.log(localStorage.getItem("compras")); // "pão,leite"  ← virou texto simples

const aluno = { nome: "Ana", nota: 9 };
localStorage.setItem("aluno", aluno);
console.log(localStorage.getItem("aluno"));   // "[object Object]"  ← perdeu tudo!
```

### 9.4 JSON: o tradutor

`JSON.stringify` transforma qualquer array/objeto em **texto** com a estrutura preservada. `JSON.parse` faz o caminho de volta.

```js
const aluno = { nome: "Ana", nota: 9, materias: ["JS", "CSS"] };

const texto = JSON.stringify(aluno);
console.log(texto); // '{"nome":"Ana","nota":9,"materias":["JS","CSS"]}'

localStorage.setItem("aluno", texto);

const recuperado = JSON.parse(localStorage.getItem("aluno"));
console.log(recuperado.materias[1]); // "CSS" ✅
```

Analogia: `stringify` é **desmontar o móvel e colocar na caixa** para a mudança. `parse` é **montar o móvel de novo** na casa nova. Na caixa, o móvel não serve para nada; depois de montado, volta a funcionar.

#### Duas funções que você vai copiar em todo projeto

```js
function salvar(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

function carregar(chave, valorPadrao) {
  const texto = localStorage.getItem(chave);
  if (texto === null) return valorPadrao;
  try {
    return JSON.parse(texto);
  } catch {
    return valorPadrao; // texto corrompido? começa do padrão
  }
}
```

Uso:

```js
let tarefas = carregar("tarefas", []);  // na primeira visita, []
tarefas.push("Estudar");
salvar("tarefas", tarefas);
```

### 🗣️ Não existe pergunta boba

**"O que é esse `try { } catch { }`?"**
É um jeito de dizer: *"tenta fazer isso; se der erro, em vez de quebrar o script, faz aquilo"*. `JSON.parse` dá erro se o texto não for JSON válido (por exemplo, se alguém editou na mão no DevTools). O `try/catch` evita que a página inteira pare por causa disso. Foi o ECMAScript 3, lá de 1999, que trouxe esse recurso (lembra da linha do tempo da Parte 1?).

**"Posso guardar a senha do usuário no `localStorage`?"**
**Não!** Qualquer script rodando na página e qualquer pessoa com acesso ao computador conseguem ler. Nunca guarde senhas, documentos ou dados sensíveis aí.

**"Qual a diferença para o `sessionStorage`?"**
Mesmos métodos, mas o `sessionStorage` é apagado quando a **aba** fecha. Bom para coisas temporárias, como um formulário em várias etapas.

### 9.5 Preferências: o caso mais simples

**Tema escuro que sobrevive ao F5**

```js
const botaoTema = document.querySelector("#tema");

function aplicarTema(tema) {
  document.body.classList.toggle("escuro", tema === "escuro");
  botaoTema.textContent = tema === "escuro" ? "☀️ Claro" : "🌙 Escuro";
}

let tema = localStorage.getItem("tema") || "claro";
aplicarTema(tema);

botaoTema.addEventListener("click", () => {
  tema = tema === "claro" ? "escuro" : "claro";
  localStorage.setItem("tema", tema);
  aplicarTema(tema);
});
```

O `|| "claro"` usa o padrão quando `getItem` devolve `null` (primeira visita).

**Lembrar o nome do usuário**

```js
const salvo = localStorage.getItem("apelido");
const saudacao = document.querySelector("#saudacao");

if (salvo) {
  saudacao.textContent = `Bem-vindo(a) de volta, ${salvo}!`;
} else {
  saudacao.textContent = "Olá! Qual é o seu apelido?";
}

document.querySelector("#formApelido").addEventListener("submit", (e) => {
  e.preventDefault();
  const apelido = document.querySelector("#apelido").value.trim();
  if (apelido === "") return;
  localStorage.setItem("apelido", apelido);
  saudacao.textContent = `Prazer, ${apelido}!`;
});
```

### 9.6 O ciclo carregar → mudar → salvar → desenhar

Em qualquer aplicação com dados salvos, o fluxo é sempre o mesmo:

```
  [abre a página]
        │
        ▼
  1. CARREGAR do localStorage para a variável de estado
        │
        ▼
  2. DESENHAR a tela a partir do estado  ◄──────────┐
        │                                            │
        ▼                                            │
  [usuário faz algo: clica, digita, envia]           │
        │                                            │
        ▼                                            │
  3. MUDAR o estado (push, splice, alterar objeto)   │
        │                                            │
        ▼                                            │
  4. SALVAR o estado no localStorage ────────────────┘
```

A regra que evita 90% dos bugs: **a tela nunca é a fonte da verdade; o array é**. Você nunca "lê a lista da tela" para descobrir o que existe; você olha o array.

### 9.7 Projeto guiado: lista de tarefas completa

`index.html`:
```html
<h1>Minhas tarefas</h1>
<form id="form">
  <input id="texto" placeholder="O que precisa ser feito?" autocomplete="off">
  <button>Adicionar</button>
</form>
<p id="resumo"></p>
<ul id="lista"></ul>
<button id="limparConcluidas">Limpar concluídas</button>
```

`style.css`:
```css
#lista { list-style: none; padding: 0; }
#lista li { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid #eee; }
#lista li.feita span { text-decoration: line-through; opacity: 0.5; }
#lista li span { flex: 1; cursor: pointer; }
.remover { border: none; background: none; color: crimson; font-size: 1.2em; cursor: pointer; }
```

`script.js`:
```js
// ---------- armazenamento ----------
function salvar(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

function carregar(chave, valorPadrao) {
  const texto = localStorage.getItem(chave);
  if (texto === null) return valorPadrao;
  try {
    return JSON.parse(texto);
  } catch {
    return valorPadrao;
  }
}

// ---------- estado ----------
let tarefas = carregar("tarefas", []);
// cada tarefa: { id: 1696170000000, texto: "Estudar", feita: false }

// ---------- elementos ----------
const form = document.querySelector("#form");
const campo = document.querySelector("#texto");
const lista = document.querySelector("#lista");
const resumo = document.querySelector("#resumo");

// ---------- desenhar ----------
function renderizar() {
  lista.innerHTML = "";

  tarefas.forEach(tarefa => {
    const li = document.createElement("li");
    li.dataset.id = tarefa.id;
    if (tarefa.feita) li.classList.add("feita");

    const span = document.createElement("span");
    span.textContent = tarefa.texto; // textContent: o texto veio do usuário!

    const botao = document.createElement("button");
    botao.textContent = "×";
    botao.classList.add("remover");
    botao.setAttribute("aria-label", `Remover ${tarefa.texto}`);

    li.append(span, botao);
    lista.append(li);
  });

  const pendentes = tarefas.filter(t => !t.feita).length;
  resumo.textContent = `${pendentes} pendente(s) de ${tarefas.length}`;
}

// ---------- mudar + salvar + desenhar ----------
function atualizar() {
  salvar("tarefas", tarefas);
  renderizar();
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const texto = campo.value.trim();
  if (texto === "") return;

  tarefas.push({ id: Date.now(), texto, feita: false });
  campo.value = "";
  atualizar();
});

lista.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (!li) return;
  const id = Number(li.dataset.id);

  if (e.target.classList.contains("remover")) {
    tarefas = tarefas.filter(t => t.id !== id);
  } else {
    const tarefa = tarefas.find(t => t.id === id);
    tarefa.feita = !tarefa.feita;
  }
  atualizar();
});

document.querySelector("#limparConcluidas").addEventListener("click", () => {
  tarefas = tarefas.filter(t => !t.feita);
  atualizar();
});

// ---------- início ----------
renderizar();
```

Leia esse código com calma. Ele usa **todos** os módulos da Parte 2:

- **Módulo 4**: funções com uma responsabilidade cada (`salvar`, `carregar`, `renderizar`, `atualizar`).
- **Módulo 5**: array de objetos, `push`, `filter`, `find`.
- **Módulo 6**: `createElement`, `textContent`, `classList`, `dataset`, `closest`.
- **Módulo 7**: `submit` com `preventDefault`, delegação no `<ul>`.
- **Módulo 8**: `.trim()` e validação de vazio.
- **Módulo 9**: `localStorage` + JSON.

#### Por que cada tarefa tem um `id`?

Na Parte 1 a gente removia pelo **índice** do array. Funciona, mas é frágil: se você filtrar a lista na tela (só "pendentes", por exemplo), o índice que aparece na tela deixa de bater com o índice do array. Um `id` único por item resolve. `Date.now()` devolve os milissegundos desde 1970, um número que muda o tempo todo — bom o suficiente como id para projetos simples.

### 🐞 Ache o bug #1

```js
let tarefas = JSON.parse(localStorage.getItem("tarefas"));
tarefas.push("Nova");
```

Funciona para quem já usou o app, mas quebra na primeira visita com `Cannot read properties of null (reading 'push')`.

<details><summary>Resposta</summary>

Na primeira visita, `getItem` devolve `null`, e `JSON.parse(null)` devolve `null`. Aí `null.push` quebra. Use um valor padrão: `JSON.parse(localStorage.getItem("tarefas")) || []`, ou a função `carregar` da seção 9.4.

</details>

### 🐞 Ache o bug #2

```js
botao.addEventListener("click", () => {
  tarefas.push(campo.value);
  renderizar();
});
```

Tudo aparece na tela, mas depois do F5 as novas tarefas somem.

<details><summary>Resposta</summary>

Mudou o estado e desenhou, mas **não salvou**. Faltou `salvar("tarefas", tarefas)` antes do `renderizar()`. É por isso que juntamos as duas na função `atualizar()`.

</details>

### 🐞 Ache o bug #3

```js
localStorage.setItem("config", { tema: "escuro", fonte: 18 });
const config = JSON.parse(localStorage.getItem("config"));
```

<details><summary>Resposta</summary>

O objeto foi gravado sem `JSON.stringify`, então foi salvo como o texto `"[object Object]"`. Depois, `JSON.parse("[object Object]")` dá `SyntaxError`. Correção: `localStorage.setItem("config", JSON.stringify({ tema: "escuro", fonte: 18 }))`.

</details>

### 🔴 Lendo o console

```
Uncaught SyntaxError: "[object Object]" is not valid JSON
    at JSON.parse (<anonymous>)
```

Tradução: *"o texto que você mandou para o `JSON.parse` não é JSON"*. Abra o DevTools → Application → Local Storage e olhe o valor salvo. Se estiver `[object Object]` ou `pão,leite`, o problema está no **salvar**, não no ler.

### 🏋️ Academia de exercícios

1. Contador de visitas: "Esta é a sua visita número X".
2. Um bloco de notas (`<textarea>`) que salva automaticamente a cada digitação e volta ao recarregar.
3. Um seletor de tamanho de fonte (P, M, G) que lembra a escolha.
4. Uma lista de favoritos: botões ⭐ em cards de filmes que ficam marcados mesmo após o F5.
5. Adicione à lista de tarefas da seção 9.7 filtros "Todas / Pendentes / Feitas", lembrando o último filtro usado.

### 🧠 Confira sua memória

1. Por que os valores das variáveis somem ao recarregar a página?
2. O que `getItem` devolve quando a chave não existe?
3. Para que servem `JSON.stringify` e `JSON.parse`?
4. Cite duas coisas que **não** devem ser guardadas no `localStorage`.
5. Descreva o ciclo carregar → desenhar → mudar → salvar.

### Mini-projeto do módulo: "Controle de gastos da semana"

Um formulário com descrição, valor e categoria (alimentação, transporte, lazer). Cada gasto vai para um array de objetos salvo no `localStorage`. A página mostra a lista, o total da semana, o total por categoria e permite remover um gasto. Tudo deve continuar lá depois de fechar e abrir o navegador.

---
## Módulo 10 — Projeto integrador final

> *"Saber as peças não é o mesmo que saber montar o quebra-cabeça. Este módulo é sobre montar."*

### 10.1 O que muda neste módulo

Não tem conceito novo de JavaScript aqui. O desafio agora é **planejar** e **organizar**. É a diferença entre saber usar martelo, serrote e trena e conseguir construir uma estante que fica em pé.

Para não ficar abstrato, vamos construir **juntos** um projeto do começo ao fim — o **"Cardápio da Cantina"** — e depois você escolhe o seu.

### 10.2 Passo 1 — Planejar no papel (antes de abrir o VS Code)

Responda por escrito:

**O que a página faz?** (em frases curtas, do ponto de vista do usuário)
- Vejo os produtos da cantina em cartões.
- Busco um produto pelo nome.
- Filtro por categoria (salgado, doce, bebida).
- Adiciono produtos ao meu pedido e vejo o total.
- O pedido continua lá se eu fechar a página.

**Quais dados existem?** (isso vira o **estado**)
```js
const produtos = [ { id, nome, preco, categoria } ];   // fixo, vem do código
let pedido = [ { idProduto, quantidade } ];            // muda, vai para o localStorage
let filtro = { texto: "", categoria: "todas" };        // muda, só na memória
```

**Quais funções vou precisar?**
- `renderizarProdutos()` — desenha os cartões que passam no filtro
- `renderizarPedido()` — desenha o pedido e o total
- `adicionarAoPedido(id)`, `removerDoPedido(id)`
- `salvar()`, `carregar()`
- `formatarPreco(valor)`

**Quais eventos?**
- `input` na busca → muda filtro → redesenha produtos
- `change` no select de categoria → idem
- `click` no botão "Adicionar" de um cartão (delegação)
- `click` no "×" de um item do pedido (delegação)

Esse planejamento cabe em meia página de caderno e economiza horas de bagunça.

### 10.3 Passo 2 — Estrutura HTML

```html
<header>
  <h1>Cantina da ETEC</h1>
</header>

<main class="layout">
  <section>
    <div class="filtros">
      <input id="busca" type="search" placeholder="Buscar produto...">
      <select id="categoria">
        <option value="todas">Todas</option>
        <option value="salgado">Salgados</option>
        <option value="doce">Doces</option>
        <option value="bebida">Bebidas</option>
      </select>
    </div>
    <div id="produtos" class="grade"></div>
    <p id="vazio" hidden>Nenhum produto encontrado.</p>
  </section>

  <aside>
    <h2>Meu pedido</h2>
    <ul id="pedido"></ul>
    <p>Total: <strong id="total">R$ 0,00</strong></p>
    <button id="limpar">Limpar pedido</button>
  </aside>
</main>
```

### 10.4 Passo 3 — CSS (incluindo as classes que o JS vai usar)

```css
.layout { display: grid; grid-template-columns: 1fr 280px; gap: 24px; }
@media (max-width: 700px) { .layout { grid-template-columns: 1fr; } }
.filtros { display: flex; gap: 8px; margin-bottom: 12px; }
.grade { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 12px; }
.cartao { border: 1px solid #ddd; border-radius: 8px; padding: 12px; display: grid; gap: 6px; }
.cartao .preco { font-weight: bold; }
.selo { font-size: .75em; text-transform: uppercase; letter-spacing: .05em; opacity: .7; }
#pedido { list-style: none; padding: 0; }
#pedido li { display: flex; justify-content: space-between; padding: 4px 0; }
```

### 10.5 Passo 4 — JavaScript, em camadas

```js
// ===== 1. DADOS =====
const produtos = [
  { id: 1, nome: "Pão de queijo", preco: 4.5, categoria: "salgado" },
  { id: 2, nome: "Coxinha", preco: 6, categoria: "salgado" },
  { id: 3, nome: "Esfiha", preco: 5.5, categoria: "salgado" },
  { id: 4, nome: "Brigadeiro", preco: 2.5, categoria: "doce" },
  { id: 5, nome: "Bolo de pote", preco: 7.5, categoria: "doce" },
  { id: 6, nome: "Suco natural", preco: 5, categoria: "bebida" },
  { id: 7, nome: "Achocolatado", preco: 4, categoria: "bebida" }
];

// ===== 2. ESTADO =====
let pedido = carregar("pedido", []);
const filtro = { texto: "", categoria: "todas" };

// ===== 3. UTILITÁRIOS =====
function salvar(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

function carregar(chave, padrao) {
  try {
    return JSON.parse(localStorage.getItem(chave)) ?? padrao;
  } catch {
    return padrao;
  }
}

function formatarPreco(valor) {
  return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

// ===== 4. ELEMENTOS =====
const elProdutos = document.querySelector("#produtos");
const elVazio = document.querySelector("#vazio");
const elPedido = document.querySelector("#pedido");
const elTotal = document.querySelector("#total");

// ===== 5. RENDERIZAÇÃO =====
function produtosFiltrados() {
  return produtos.filter(p => {
    const bateTexto = p.nome.toLowerCase().includes(filtro.texto.toLowerCase());
    const bateCategoria = filtro.categoria === "todas" || p.categoria === filtro.categoria;
    return bateTexto && bateCategoria;
  });
}

function renderizarProdutos() {
  const lista = produtosFiltrados();
  elProdutos.innerHTML = lista.map(p => `
    <article class="cartao">
      <span class="selo">${p.categoria}</span>
      <h3>${p.nome}</h3>
      <span class="preco">${formatarPreco(p.preco)}</span>
      <button data-id="${p.id}" class="adicionar">Adicionar</button>
    </article>
  `).join("");
  elVazio.hidden = lista.length > 0;
}

function renderizarPedido() {
  elPedido.innerHTML = "";
  let total = 0;

  pedido.forEach(item => {
    const produto = produtos.find(p => p.id === item.idProduto);
    const subtotal = produto.preco * item.quantidade;
    total += subtotal;

    const li = document.createElement("li");
    li.innerHTML = `
      <span>${item.quantidade}× ${produto.nome}</span>
      <span>${formatarPreco(subtotal)} <button data-id="${produto.id}" class="remover">×</button></span>
    `;
    elPedido.append(li);
  });

  elTotal.textContent = formatarPreco(total);
}

// ===== 6. AÇÕES (mudam o estado) =====
function adicionarAoPedido(id) {
  const item = pedido.find(i => i.idProduto === id);
  if (item) {
    item.quantidade++;
  } else {
    pedido.push({ idProduto: id, quantidade: 1 });
  }
  salvar("pedido", pedido);
  renderizarPedido();
}

function removerDoPedido(id) {
  pedido = pedido.filter(i => i.idProduto !== id);
  salvar("pedido", pedido);
  renderizarPedido();
}

// ===== 7. EVENTOS =====
document.querySelector("#busca").addEventListener("input", (e) => {
  filtro.texto = e.target.value;
  renderizarProdutos();
});

document.querySelector("#categoria").addEventListener("change", (e) => {
  filtro.categoria = e.target.value;
  renderizarProdutos();
});

elProdutos.addEventListener("click", (e) => {
  if (e.target.classList.contains("adicionar")) {
    adicionarAoPedido(Number(e.target.dataset.id));
  }
});

elPedido.addEventListener("click", (e) => {
  if (e.target.classList.contains("remover")) {
    removerDoPedido(Number(e.target.dataset.id));
  }
});

document.querySelector("#limpar").addEventListener("click", () => {
  pedido = [];
  salvar("pedido", pedido);
  renderizarPedido();
});

// ===== 8. INÍCIO =====
renderizarProdutos();
renderizarPedido();
```

> Aqui usamos `innerHTML` nos produtos porque os nomes vêm do **nosso** array, não do usuário. Se os produtos fossem cadastrados por um formulário, trocaríamos por `createElement` + `textContent` (Módulo 6).

#### Os 8 blocos que todo projeto pode ter

1. **Dados** fixos
2. **Estado** (o que muda)
3. **Utilitários** (funções genéricas: formatar, salvar, carregar)
4. **Elementos** do DOM guardados em `const`
5. **Renderização** (estado → tela)
6. **Ações** (mudam o estado, salvam, redesenham)
7. **Eventos** (ligam o usuário às ações)
8. **Início** (primeira renderização)

Manter essa ordem no arquivo faz qualquer colega (e você mesmo, daqui a um mês) achar as coisas rápido.

### 🎬 Nos bastidores — `??` e `toLocaleString`

Dois recursos novos apareceram de carona:

- `a ?? b` (*nullish coalescing*, ES2020) devolve `b` só quando `a` é `null` ou `undefined`. Diferente do `||`, que também troca `0`, `""` e `false`. No `carregar`, `JSON.parse(null)` dá `null`, e o `??` troca pelo padrão.
- `valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })` formata dinheiro no padrão brasileiro (`R$ 4,50`) sem você precisar trocar ponto por vírgula na mão.

### 10.6 Passo 5 — Testes manuais (roteiro)

Teste como se fosse o usuário mais desastrado do mundo:

| # | Ação | Esperado | ✅/❌ |
|---|---|---|---|
| 1 | Abrir pela primeira vez (Local Storage vazio) | Página carrega sem erro no console | |
| 2 | Buscar "cox" | Só a Coxinha aparece | |
| 3 | Buscar "COX" | Só a Coxinha aparece (maiúsculas não importam) | |
| 4 | Buscar "xyz" | Mensagem "Nenhum produto encontrado" | |
| 5 | Categoria "Doces" + busca "pão" | Lista vazia + mensagem | |
| 6 | Adicionar a mesma coisa 3 vezes | Um item com "3×", não três itens | |
| 7 | F5 no meio do pedido | Pedido continua igual | |
| 8 | Remover um item | Some e o total atualiza | |
| 9 | Editar o Local Storage na mão para `abc` e dar F5 | Página não quebra | |
| 10 | Abrir no celular (ou F12 → modo dispositivo) | Layout em uma coluna | |

### 10.7 Passo 6 — Lista de bugs conhecidos

Todo projeto profissional tem um arquivo `README.md` com o que **ainda não funciona**. Exemplo honesto:

```markdown
## Bugs conhecidos
- Não dá para diminuir a quantidade de um item, só remover tudo.
- Se um produto for removido do array `produtos`, um pedido salvo com ele quebra a página.
- O total não considera descontos.
```

Isso não é sinal de fraqueza. É sinal de que você **testou** e **entende** o próprio código.

### 10.8 Escolha o seu projeto

| Projeto | Dificuldade | Desafio principal |
|---|---|---|
| **Lista de tarefas completa** (prioridade, filtro, data) | ⭐⭐ | estado + filtros |
| **Quiz com ranking** (nome do jogador, top 5 salvo) | ⭐⭐⭐ | fluxo de telas + ordenação |
| **Controle de gastos** (categorias, total, gráfico em barras com `div`) | ⭐⭐⭐ | cálculos + `style.width` |
| **Catálogo com carrinho** (como o exemplo, com mais recursos) | ⭐⭐⭐ | dois estados ligados |
| **Agenda de provas** (matéria, data, dias restantes) | ⭐⭐⭐ | datas com `new Date()` |
| **Jogo da memória** (cartas viradas, pares, tentativas, recorde) | ⭐⭐⭐⭐ | lógica de jogo + `setTimeout` |

**Requisitos mínimos para qualquer um:**
- pelo menos um **array de objetos** como estado;
- pelo menos **uma** função de renderização que redesenha a partir do estado;
- pelo menos **três** tipos de evento diferentes;
- pelo menos **um** formulário com validação;
- dados persistidos no **`localStorage`**;
- código organizado nos blocos da seção 10.5;
- `README.md` com descrição, como usar e bugs conhecidos.

### 10.9 Rubrica de avaliação

| Critério | Insuficiente (0–1) | Básico (2) | Bom (3) | Excelente (4) |
|---|---|---|---|---|
| **Funcionamento** | não roda ou quebra no uso comum | funções principais com falhas | funciona no uso normal | funciona até nos casos estranhos do roteiro de testes |
| **Organização** | tudo num bloco só | algumas funções | funções com nomes claros | blocos bem separados, sem repetição |
| **DOM e eventos** | não usa ou usa errado | usa com `onclick` no HTML ou `style` em excesso | `addEventListener` e `classList` corretos | usa delegação e `textContent` com dados do usuário |
| **Persistência** | não salva | salva mas quebra na 1ª visita | salva e carrega com padrão | trata dados corrompidos |
| **Explicação** | não sabe explicar | explica o "o quê" | explica o "porquê" | explica uma alternativa que descartou e por quê |

### 10.10 Apresentação (3 a 5 minutos)

Roteiro sugerido:
1. **30 s** — Qual problema a página resolve e para quem.
2. **2 min** — Demonstração ao vivo (com F5 no meio, para provar a persistência!).
3. **1 min** — Um trecho de código de que você se orgulha e por quê.
4. **1 min** — O bug mais difícil e como você descobriu a causa.
5. **30 s** — O que faria se tivesse mais uma semana.

### 🧠 Confira sua memória

1. Por que planejar no papel antes de programar?
2. Quais são os 8 blocos de organização do arquivo?
3. Por que a tela nunca deve ser a "fonte da verdade"?
4. Para que serve uma lista de bugs conhecidos?

---

## Módulo bônus — Primeiros passos além do navegador

> *"Até aqui, os dados moravam dentro do seu código. Agora eles vão chegar de longe."*

### B.1 O que é uma API (com uma analogia de restaurante)

Você está num restaurante. Você (o **cliente**, o seu JavaScript) não entra na cozinha (o **servidor**). Você faz o pedido ao **garçom** (a **API**), seguindo o **cardápio** (a **documentação**). O garçom leva o pedido, a cozinha prepara, e o garçom traz o prato (os **dados**, geralmente em **JSON**).

Uma API web é um endereço (URL) que, em vez de devolver uma página HTML para você ler, devolve **dados** para o seu programa usar.

Abra no navegador: `https://viacep.com.br/ws/29010000/json/`
Você vai ver um JSON com o endereço daquele CEP. Isso é uma API pública e gratuita, brasileira.

### B.2 `fetch`: fazendo o pedido

```js
fetch("https://viacep.com.br/ws/29010000/json/")
  .then(resposta => resposta.json())
  .then(dados => {
    console.log(dados.logradouro);
    console.log(dados.localidade);
  })
  .catch(erro => {
    console.log("Não deu para buscar:", erro);
  });
```

Leia assim:
1. **`fetch(url)`** — "garçom, leva esse pedido". Isso **demora** (a internet não é instantânea), então o JavaScript **não fica parado esperando**; ele segue e volta aqui quando a resposta chegar.
2. **`.then(resposta => resposta.json())`** — "quando o prato chegar, tira da embalagem" (converte o texto JSON em objeto).
3. **`.then(dados => ...)`** — "agora, come" (usa os dados).
4. **`.catch(...)`** — "se o pedido der errado (sem internet, endereço errado), faz isso".

### ✏️ Aponte seu lápis

```js
console.log("1");
fetch("https://viacep.com.br/ws/29010000/json/")
  .then(r => r.json())
  .then(() => console.log("2"));
console.log("3");
```

<details><summary>Resposta</summary>

`1`, `3`, `2`. O `fetch` não trava o resto do código: o `"3"` aparece antes porque a resposta da internet chega depois. Isso se chama código **assíncrono**.

</details>

### B.3 Exemplo prático: busca de CEP com preenchimento automático

`index.html`:
```html
<form id="formCep">
  <label for="cep">CEP</label>
  <input id="cep" maxlength="9" placeholder="00000-000">
  <button>Buscar</button>
</form>
<p id="status"></p>
<label>Rua <input id="rua" readonly></label>
<label>Bairro <input id="bairro" readonly></label>
<label>Cidade <input id="cidade" readonly></label>
<label>UF <input id="uf" readonly></label>
```

`script.js`:
```js
const msgStatus = document.querySelector("#status");

document.querySelector("#formCep").addEventListener("submit", (e) => {
  e.preventDefault();
  const cep = document.querySelector("#cep").value.replace(/\D/g, "");

  if (cep.length !== 8) {
    msgStatus.textContent = "O CEP precisa ter 8 dígitos.";
    return;
  }

  msgStatus.textContent = "Buscando...";

  fetch(`https://viacep.com.br/ws/${cep}/json/`)
    .then(resposta => resposta.json())
    .then(dados => {
      if (dados.erro) {
        msgStatus.textContent = "CEP não encontrado.";
        return;
      }
      document.querySelector("#rua").value = dados.logradouro;
      document.querySelector("#bairro").value = dados.bairro;
      document.querySelector("#cidade").value = dados.localidade;
      document.querySelector("#uf").value = dados.uf;
      msgStatus.textContent = "Endereço encontrado!";
    })
    .catch(() => {
      msgStatus.textContent = "Falha na conexão. Tente novamente.";
    });
});
```

Repare: **validação** (Módulo 8), **evento submit** (Módulo 7), **DOM** (Módulo 6) e agora dados vindos da internet. Todo o resto da apostila continua valendo.

### B.4 Mesma coisa com `async`/`await` (só para conhecer)

```js
async function buscarCep(cep) {
  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const dados = await resposta.json();
    return dados;
  } catch {
    return null;
  }
}
```

`await` significa "espera essa promessa ser cumprida antes de seguir para a próxima linha" — e só pode ser usado dentro de funções marcadas com `async`. O resultado é o mesmo do `.then`, mas o código fica com cara de "passo a passo". Você vai aprofundar isso no próximo curso.

### B.5 Outras APIs públicas para brincar

| API | O que devolve | Endereço de exemplo |
|---|---|---|
| ViaCEP | endereço de um CEP | `https://viacep.com.br/ws/01001000/json/` |
| BrasilAPI | feriados, bancos, CNPJ | `https://brasilapi.com.br/api/feriados/v1/2026` |
| IBGE | estados e municípios | `https://servicodados.ibge.gov.br/api/v1/localidades/estados` |
| PokéAPI | dados de Pokémon | `https://pokeapi.co/api/v2/pokemon/pikachu` |

> Essas APIs são mantidas por terceiros e podem mudar ou sair do ar. Teste no navegador antes da aula.

### 🎬 Nos bastidores — o mapa do território

O que vem depois deste curso (só o mapa, sem estudar agora):

- **Promises e `async`/`await`** — dominar código assíncrono.
- **Módulos** (`import`/`export`) — quebrar o projeto em vários arquivos `.js`.
- **Node.js** — o JavaScript rodando fora do navegador, em servidores.
- **TypeScript** — JavaScript com tipos verificados antes de rodar.
- **React, Vue, Svelte** — bibliotecas que automatizam exatamente o ciclo "estado → renderizar" que você fez na mão.

Quem entende o `renderizar()` do Módulo 9 entende a ideia central do React. Você está mais perto do que imagina.

### 🧠 Confira sua memória

1. Explique API usando a analogia do restaurante.
2. Por que o `fetch` não trava o resto do código?
3. Para que serve o `.catch`?
4. Por que o `fetch` precisa de dois `.then`?

---

## Considerações finais para quem está lecionando

- **Sequência dos exercícios.** Cada módulo tem 10 exercícios na lista que acompanha esta apostila, em ordem crescente de dificuldade: os 4 primeiros fixam o básico, os 4 do meio combinam com módulos anteriores e os 2 últimos são desafios. Uma boa divisão é 1–4 em aula, 5–8 para casa e 9–10 como extra.
- **Aponte seu lápis em voz alta.** Projete o código, peça para cada aluno escrever a previsão no caderno, faça uma votação rápida e só depois rode. A discussão sobre quem errou e por quê é o momento mais rico da aula.
- **Ache o bug em dupla.** Um aluno lê o código em voz alta, o outro procura o erro. Depois trocam.
- **Console aberto sempre.** Combine com a turma: o F12 fica aberto o tempo todo. Quem mostrar um erro vermelho e explicar o que ele diz ganha o "selo de detetive" da aula.
- **Projeto integrador em duplas**, com o roteiro de testes da seção 10.6 aplicado por **outra** dupla (teste cruzado).
- **Sem `localStorage` no laboratório?** Em algumas redes, o navegador limpa os dados ao fechar. Peça para testarem a persistência com F5, não fechando o navegador.
