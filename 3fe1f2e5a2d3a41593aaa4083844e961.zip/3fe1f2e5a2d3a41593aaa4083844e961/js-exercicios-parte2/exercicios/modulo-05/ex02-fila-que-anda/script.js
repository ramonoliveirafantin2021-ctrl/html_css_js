/*
  Módulo 5 — Arrays e objetos
  Exercício 02 — Fila que anda
  Nível: Básico

  Objetivo: push, pop, shift e unshift ligados a botões.

  Como fazer: leia cada TODO, resolva um de cada vez e teste no navegador
  antes de passar para o próximo. Console aberto (F12)!
*/

const fila = ["Ana", "Bruno"];

function mostrarFila() {
  document.querySelector("#fila").textContent = fila.join(" → ") || "(vazia)";
}

// TODO 1: "Entrar no fim" adiciona o nome digitado no FIM da fila (push).
// TODO 2: "Prioridade" adiciona no INÍCIO (unshift).
// TODO 3: "Atender próximo" remove o PRIMEIRO (shift) e mostra em #aviso
//         "Atendendo: NOME". Se a fila estiver vazia, mostre "Ninguém na fila".
// TODO 4: Depois de cada ação, chame mostrarFila() e limpe o input.

mostrarFila();
